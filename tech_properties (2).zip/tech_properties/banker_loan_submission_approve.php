<?php
session_start();
include 'config.php';

if (!isset($_SESSION['banker_id'])) {
    header("Location: banker_login.php");
    exit();
}

if (isset($_GET['submission_id'])) {
    $submission_id = intval($_GET['submission_id']);
    
    $query = "SELECT * FROM loan_submissions WHERE submission_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $submission_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $submission = $result->fetch_assoc();

    if (!$submission) {
        die("No submission found.");
    }
} else {
    die("Submission ID is missing.");
}

$query = "SELECT lawyer_id, firm_number, lawyer_fullname FROM lawyers";
$lawyers = $conn->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Approve Loan Submission</title>
</head>
<body>
<div class="container mt-5">
    <h2>Approve Loan Submission</h2>
    <form action="banker_loan_submission_approve_process.php" method="POST">
        <input type="hidden" name="submission_id" value="<?php echo htmlspecialchars($submission_id); ?>">
        <div class="form-group">
            <label for="lawyer_id">Select Lawyer:</label>
            <select name="lawyer_id" class="form-control" required>
                <option value="">Select a lawyer</option>
                <?php while ($lawyer = $lawyers->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($lawyer['lawyer_id']); ?>">
                        <?php echo htmlspecialchars($lawyer['lawyer_fullname'] . " - " . $lawyer['firm_number']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-success">Approve Submission</button>
    </form>
</div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>



