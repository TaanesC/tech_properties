<?php
require 'config.php'; 

$created_at_from = isset($_GET['created_at_from']) ? $_GET['created_at_from'] : '';
$created_at_to = isset($_GET['created_at_to']) ? $_GET['created_at_to'] : '';
$price_min = isset($_GET['price_min']) ? $_GET['price_min'] : '';
$price_max = isset($_GET['price_max']) ? $_GET['price_max'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$rent_or_sale = isset($_GET['rent_or_sale']) ? $_GET['rent_or_sale'] : '';

$query = "SELECT ra.property_id, p.title, p.location, p.price, p.type, ra.status, ra.created_at 
          FROM rented_sold_analytics ra
          JOIN properties p ON ra.property_id = p.property_id
          WHERE 1";

if ($created_at_from) {
    $query .= " AND ra.created_at >= ?";
}
if ($created_at_to) {
    $query .= " AND ra.created_at <= ?";
}

if ($price_min) {
    $query .= " AND p.price >= ?";
}
if ($price_max) {
    $query .= " AND p.price <= ?";
}

if ($type) {
    $query .= " AND p.type = ?";
}

if ($rent_or_sale) {
    $query .= " AND p.rent_or_sale = ?";
}

$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Query preparation failed: " . $conn->error);
}

$types = '';
$params = [];

if ($created_at_from) {
    $types .= 's';
    $params[] = $created_at_from;
}
if ($created_at_to) {
    $types .= 's';
    $params[] = $created_at_to;
}
if ($price_min) {
    $types .= 'i';
    $params[] = $price_min;
}
if ($price_max) {
    $types .= 'i';
    $params[] = $price_max;
}
if ($type) {
    $types .= 's';
    $params[] = $type;
}
if ($rent_or_sale) {
    $types .= 's';
    $params[] = $rent_or_sale;
}

if (!empty($types)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$data = $result->fetch_all(MYSQLI_ASSOC);

$query_for_graph = "SELECT COUNT(*) AS count, ra.status, DATE(ra.created_at) AS date
                    FROM rented_sold_analytics ra
                    GROUP BY DATE(ra.created_at), ra.status
                    ORDER BY date DESC";
$graph_result = $conn->query($query_for_graph);

$graph_data = [];
while ($row = $graph_result->fetch_assoc()) {
    $graph_data[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rented/Sold Property Analytics</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
        .navbar {    
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;       
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
        <div>rrr</div>
         <div>rrr</div>
        

<div class="container mt-4">
    <h2>Rented/Sold Property Analytics</h2>

    <form method="GET" action="admin_rented_sold_analytics.php">
        <div class="row">
            <div class="col-md-3">
                <label for="created_at" class="form-label">Select Date Range</label>
                <input type="date" id="created_at_from" name="created_at_from" class="form-control" value="<?= isset($_GET['created_at_from']) ? $_GET['created_at_from'] : '' ?>">
                <input type="date" id="created_at_to" name="created_at_to" class="form-control mt-2" value="<?= isset($_GET['created_at_to']) ? $_GET['created_at_to'] : '' ?>">
            </div>

            <div class="col-md-3">
                <label for="price" class="form-label">Select Price Range</label>
                <input type="number" id="price_min" name="price_min" class="form-control" placeholder="Min Price" value="<?= isset($_GET['price_min']) ? $_GET['price_min'] : '' ?>">
                <input type="number" id="price_max" name="price_max" class="form-control mt-2" placeholder="Max Price" value="<?= isset($_GET['price_max']) ? $_GET['price_max'] : '' ?>">
            </div>

            <div class="col-md-3">
                <label for="type" class="form-label">Select Property Type</label>
                <select id="type" name="type" class="form-select">
                    <option value="">All</option>
                    <option value="apartment" <?= isset($_GET['type']) && $_GET['type'] == 'apartment' ? 'selected' : '' ?>>Apartment</option>
                    <option value="house" <?= isset($_GET['type']) && $_GET['type'] == 'house' ? 'selected' : '' ?>>House</option>
                </select>
            </div>

            <div class="col-md-3">
                <label for="rent_or_sale" class="form-label">Rent or Sale</label>
                <select id="rent_or_sale" name="rent_or_sale" class="form-select">
                    <option value="">All</option>
                    <option value="rent" <?= isset($_GET['rent_or_sale']) && $_GET['rent_or_sale'] == 'rent' ? 'selected' : '' ?>>Rent</option>
                    <option value="sale" <?= isset($_GET['rent_or_sale']) && $_GET['rent_or_sale'] == 'sale' ? 'selected' : '' ?>>Sale</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Apply Filters</button>
    </form>

    <div class="mt-4">
        <h4>Analytics Data</h4>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Property Title</th>
                    <th>Location</th>
                    <th>Price</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($data as $row): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['title']) ?></td>
                        <td><?= htmlspecialchars($row['location']) ?></td>
                        <td><?= number_format($row['price'], 2) ?></td>
                        <td><?= htmlspecialchars($row['type']) ?></td>
                        <td><?= htmlspecialchars($row['status']) ?></td>
                        <td><?= htmlspecialchars($row['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div id="graph-container" class="mt-4">
        <h4>Rented vs. Sold Properties Over Time</h4>
        <canvas id="analyticsGraph" width="400" height="200"></canvas>
    </div>
</div>

<script>
    const graphData = <?php echo json_encode($graph_data); ?>;

    const rentedData = graphData.filter(item => item.status === 'rented').map(item => item.count);
    const soldData = graphData.filter(item => item.status === 'sold').map(item => item.count);
    const dates = [...new Set(graphData.map(item => item.date))];

    const ctx = document.getElementById('analyticsGraph').getContext('2d');
    const analyticsGraph = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: dates,
            datasets: [
                {
                    label: 'Rented',
                    data: rentedData,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Sold',
                    data: soldData,
                    backgroundColor: 'rgba(255, 99, 132, 0.2)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            scales: {
                x: { 
                    beginAtZero: true 
                }
            }
        }
    });
</script>

</body>
</html>

