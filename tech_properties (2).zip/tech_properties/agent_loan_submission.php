<?php
session_start();
include 'config.php';

if (isset($_SESSION['message'])) {
    echo '<div class="alert alert-success">' . $_SESSION['message'] . '</div>';
    unset($_SESSION['message']); // Clear the message after displaying
}

if (!isset($_SESSION['agent_id'])) {
    die("You must be logged in as an agent to view this page.");
}

$agent_id = $_SESSION['agent_id'];

$query = "SELECT ls.submission_id, u.user_fullname, ls.id_proof, p.title, p.location, p.type, p.price, ls.created_at,ls.status
          FROM loan_submissions ls
          JOIN users u ON ls.user_id = u.user_id
          JOIN properties p ON ls.property_id = p.property_id
          WHERE ls.agent_id = ?";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("SQL prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $agent_id);
$stmt->execute();
$result = $stmt->get_result();



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Submission Requests</title>
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    
    <div>rrr</div>
<div class="container mt-5">
    <h2>Loan Submission Requests</h2>
    <table class="table">
        <thead>
            <tr>
                <th>User Full Name</th>
                <th>ID Proof</th>
                <th>Title</th>
                <th>Location</th>
                <th>Type</th>
                <th>Price</th>
                <th>Created At</th>
                                <th>Status</th>

                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['user_fullname']); ?></td>
                        <td><a href="<?php echo htmlspecialchars($row['id_proof']); ?>" target="_blank">View Document</a></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['location']); ?></td>
                    <td><?php echo htmlspecialchars($row['type']); ?></td>
                    <td><?php echo htmlspecialchars($row['price']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                                        <td><?php echo htmlspecialchars($row['status']); ?></td>

                    <td>
                        <a href="agent_loan_submission_view_full_details.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-info">View Full Details</a>
                        <a href="agent_loan_submission_submit_to_banker.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-success">Submit to Banker</a>
                        <a href="agent_loan_submission_reject.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-danger">Reject</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>



