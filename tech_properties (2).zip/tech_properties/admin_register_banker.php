<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['admin_email'])) {
    header('Location: admin_login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $banker_email = $_POST['banker_email'];
    $banker_fullname = $_POST['banker_fullname'];
    $banker_phonenumber = $_POST['banker_phonenumber'];
    $bank_id = $_POST['bank_id'];
    $bank_name = $_POST['bank_name'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO bankers (banker_email, banker_fullname, banker_phonenumber, bank_id, bank_name, banker_password) VALUES (?, ?, ?, ?, ?, ?)";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("ssssss", $banker_email, $banker_fullname, $banker_phonenumber, $bank_id, $bank_name, $hashed_password);
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Banker registered successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error registering banker: " . $conn->error . "</div>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Banker - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%; 
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000; 
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px; 
        }
        .container {
            max-width: 600px; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Register Banker</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="banker_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="banker_email" name="banker_email" required>
            </div>
            <div class="mb-3">
                <label for="banker_fullname" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="banker_fullname" name="banker_fullname" required>
            </div>
            <div class="mb-3">
                <label for="banker_phonenumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="banker_phonenumber" name="banker_phonenumber" required>
            </div>
            <div class="mb-3">
                <label for="bank_id" class="form-label">Bank ID</label>
                <input type="text" class="form-control" id="bank_id" name="bank_id" required>
            </div>
            <div class="mb-3">
                <label for="bank_name" class="form-label">Bank Name</label>
                <input type="text" class="form-control" id="bank_name" name="bank_name" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Register Banker</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



