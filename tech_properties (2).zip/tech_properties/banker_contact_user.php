<?php
require 'config.php'; // Include your database connection

// Get the submission_id from the URL
$submission_id = isset($_GET['submission_id']) ? (int)$_GET['submission_id'] : 0;

// Check if submission_id is valid
if ($submission_id <= 0) {
    die("Invalid submission ID");
}

// Get the associated property_id from the loan submission table
$query = "SELECT submission_id, property_id FROM loan_submissions WHERE submission_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $submission_id);
$stmt->execute();
$result = $stmt->get_result();

// If no submission found, exit
if ($result->num_rows === 0) {
    die("Submission not found");
}

$submission = $result->fetch_assoc();
$property_id = $submission['property_id'];

// Get the property title and agent_id based on the property_id
$query = "SELECT p.title, p.agent_id FROM properties p WHERE p.property_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $property_id);
$stmt->execute();
$result = $stmt->get_result();

// If no property found, exit
if ($result->num_rows === 0) {
    die("Property not found");
}

$property = $result->fetch_assoc();
$property_title = $property['title'];
$agent_id = $property['agent_id'];

// Get previous messages between the banker and the user for this property
$banker_id = 1; // Replace with the actual logged-in banker ID
$query = "SELECT m.message_id, m.sender_id, m.receiver_id, m.sender_role, m.receiver_role, m.message_text, m.created_at
          FROM messages m
          WHERE m.property_id = ? AND ((m.sender_role = 'user' AND m.receiver_role = 'banker' AND m.receiver_id = ?)
          OR (m.sender_role = 'banker' AND m.receiver_role = 'user' AND m.sender_id = ?))";
$stmt = $conn->prepare($query);
$stmt->bind_param('iii', $property_id, $banker_id, $banker_id);
$stmt->execute();
$messages = $stmt->get_result();

// Handle message sending
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message_text = $_POST['message_text'];
    $sender_role = 'banker';
    $receiver_role = 'user';

    // Insert the new message into the database
    $query = "INSERT INTO messages (sender_id, receiver_id, sender_role, receiver_role, message_text, created_at, property_id)
              VALUES (?, ?, ?, ?, ?, NOW(), ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iisssi', $banker_id, $agent_id, $sender_role, $receiver_role, $message_text, $property_id);
    $stmt->execute();

    // Redirect to the same page to show the new message
    header("Location: banker_contact_user.php?submission_id=" . $submission_id);
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat with Agent</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-4">
    <h2>Chat about the Property: <?= htmlspecialchars($property_title) ?></h2>

    <div class="card">
        <div class="card-header">
            Chat with Agent
        </div>
        <div class="card-body">
            <div class="chat-box" style="max-height: 400px; overflow-y: scroll;">
                <?php while ($message = $messages->fetch_assoc()): ?>
                    <div class="message <?php echo $message['sender_role'] == 'banker' ? 'bg-success text-white' : 'bg-primary text-white'; ?> mb-2 p-2 rounded">
                        <strong><?= htmlspecialchars($message['sender_role']) ?>:</strong>
                        <p><?= htmlspecialchars($message['message_text']) ?></p>
                        <small class="text-muted"><?= $message['created_at'] ?></small>
                    </div>
                <?php endwhile; ?>
            </div>

            <!-- Send Message Form -->
            <form method="POST">
                <div class="input-group mt-3">
                    <textarea name="message_text" class="form-control" placeholder="Type your message..." rows="3" required></textarea>
                    <button type="submit" class="btn btn-primary">Send</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>





