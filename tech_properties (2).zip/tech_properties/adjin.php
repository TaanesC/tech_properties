<?php
// Database connection
$host = 'localhost';
$db = 'tech_properties'; // Replace with your actual database name
$username = 'root'; // Replace with your actual database username
$password = ''; // Replace with your actual database password

try {
    $conn = new PDO("mysql:host=$host;dbname=$db", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Prepare data
    $admin_email = 'admin@gmail.com';
    $admin_password = 'TMS21ck24#';

    // Hash the password
    $hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

    // Insert into the admin table
    $sql = "INSERT INTO admin (admin_email, admin_password) VALUES (:admin_email, :admin_password)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':admin_email', $admin_email);
    $stmt->bindParam(':admin_password', $hashed_password);

    if ($stmt->execute()) {
        echo "Admin user created successfully with hashed password.";
    } else {
        echo "Error: Could not create admin user.";
    }
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>


