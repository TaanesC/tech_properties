<?php
session_start();
require 'config.php'; 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ren_number = $_POST['ren_number'];
    $password = $_POST['password'];

    $sql = "SELECT agent_id, agent_password FROM agents WHERE ren_number = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $ren_number);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($agent_id, $hashed_password);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION['agent_id'] = $agent_id;
                
                header('Location: agent_dashboard.php');
                exit();
            } else {
                $error_message = "Invalid password.";
            }
        } else {
            $error_message = "Agent not found with that REN number.";
        }
        $stmt->close();
    } else {
        $error_message = "Error with database query.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Login - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%; 
            padding: 20px;
            position: fixed; 
            top: 0;
            left: 0;
            z-index: 1000; 
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 70px; 
        }
        .container {
            max-width: 400px; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Agent Login</h1>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="ren_number" class="form-label">REN Number</label>
                <input type="text" class="form-control" id="ren_number" name="ren_number" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


