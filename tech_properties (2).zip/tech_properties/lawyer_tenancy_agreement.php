<?php
include 'config.php';

session_start();
if (!isset($_SESSION['lawyer_id'])) {
    header("Location: lawyer_login.php");
    exit;
}

$lawyer_id = $_SESSION['lawyer_id'];
$query = "
    SELECT ta.agreement_id, p.title, ta.property_address, ta.monthly_rental, ta.deposit, 
           ta.rental_start_date, ta.rental_end_date, ta.contract_period, ta.status,
           ta.agreement_pdf, ta.user_signed_agreement_pdf, ta.landlord_signed_agreement_pdf
    FROM tenancy_agreements ta
    JOIN properties p ON ta.property_id = p.property_id
    WHERE ta.status = 'submitted' AND ta.lawyer_id = ?";

$stmt = $conn->prepare($query);
$stmt->bind_param('i', $lawyer_id);
$stmt->execute();
$result = $stmt->get_result();

// Handle file upload and status update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['agreement_id'])) {
    $agreement_id = $_POST['agreement_id'];

    // Check if a file was uploaded
    if (isset($_FILES['stamped_agreement_pdf']) && $_FILES['stamped_agreement_pdf']['error'] == 0) {
        $upload_dir = 'stamped_agreement_pdf/';
        $file_name = basename($_FILES['stamped_agreement_pdf']['name']);
        $target_file = $upload_dir . $file_name;

        // Move the uploaded file to the target directory
        if (move_uploaded_file($_FILES['stamped_agreement_pdf']['tmp_name'], $target_file)) {
            // Update the tenancy agreement with the stamped PDF and change the status to 'stamped'
            $new_status = 'stamped';
            $update_query = "UPDATE tenancy_agreements SET status = ?, stamped_agreement_pdf = ? WHERE agreement_id = ?";
            $stmt = $conn->prepare($update_query);
            $stmt->bind_param('ssi', $new_status, $target_file, $agreement_id);

            if ($stmt->execute()) {
                header('Location: lawyer_tenancy_agreement.php?upload=success');
                exit;
            } else {
                echo "Error updating record: " . $stmt->error;
            }
        } else {
            echo "Error uploading file.";
        }
    } else {
        echo "No file uploaded or file upload error.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lawyer Tenancy Agreement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h2>Lawyer Tenancy Agreements</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Property Title</th>
                <th>Property Address</th>
                <th>Monthly Rental</th>
                <th>Deposit</th>
                <th>Rental Start Date</th>
                <th>Rental End Date</th>
                <th>Contract Period</th>
                <th>Status</th>
                <th>Agreement PDF</th>
                <th>User Signed Agreement</th>
                <th>Landlord Signed Agreement</th>
                <th>Submit Stamped Agreement</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['property_address']); ?></td>
                    <td><?php echo htmlspecialchars($row['monthly_rental']); ?></td>
                    <td><?php echo htmlspecialchars($row['deposit']); ?></td>
                    <td><?php echo htmlspecialchars($row['rental_start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['rental_end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['contract_period']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td><a href="<?php echo htmlspecialchars($row['agreement_pdf']); ?>" target="_blank">View Agreement</a></td>
                    <td><a href="<?php echo htmlspecialchars($row['user_signed_agreement_pdf']); ?>" target="_blank">View User Signed Agreement</a></td>
                    <td><a href="<?php echo htmlspecialchars($row['landlord_signed_agreement_pdf']); ?>" target="_blank">View Landlord Signed Agreement</a></td>
                    <td>
                        <form method="POST" enctype="multipart/form-data">
                            <input type="hidden" name="agreement_id" value="<?php echo $row['agreement_id']; ?>">
                            <div class="form-group">
                                <label for="stamped_agreement_pdf">Upload Stamped Agreement:</label>
                                <input type="file" name="stamped_agreement_pdf" class="form-control-file" required>
                            </div>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>


