<?php
session_start();
require 'config.php';

if (!$conn) {
    die("Database connection failed.");
}

if (isset($_SESSION['user_id'])) {
    header('Location: user_dashboard.php'); 
    exit();
}

if (isset($_POST['login'])) {
    $user_phonenumber = $_POST['user_phonenumber'];
    $user_password = $_POST['user_password'];

    // Check if user exists
    $query = "SELECT user_id, user_password FROM users WHERE user_phonenumber = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $user_phonenumber);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($user_password, $user['user_password'])) {
            // Store user_id in session instead of user_phonenumber
            $_SESSION['user_id'] = $user['user_id']; 
            
            if (isset($_SESSION['redirect_after_login'])) {
                $redirect_url = $_SESSION['redirect_after_login'];
                unset($_SESSION['redirect_after_login']); // Clear the redirect after using it
                header("Location: $redirect_url");
            } else {
                header('Location: user_dashboard.php');
            }
            exit();
        } else {
            $error_message = "Invalid phone number or password!";
        }
    } else {
        $error_message = "User not found!";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Login | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f7f7f7;
        }
        .container {
            max-width: 400px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header-title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .navbar {
            background-color: #001f3f;
            padding: 20px;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">TECH PROPERTIES</a>
    </nav>

    <div class="container mt-4">
        <div class="header-title">User Login</div>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <form action="" method="POST">
            <div class="mb-3">
                <label for="user_phonenumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="user_phonenumber" name="user_phonenumber" required>
            </div>
            <div class="mb-3">
                <label for="user_password" class="form-label">Password</label>
                <input type="password" class="form-control" id="user_password" name="user_password" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
            <p class="mt-2">Haven't registered yet? <a href="user_register.php">Register here</a></p>
        </form>
    </div>

</body>
</html>





