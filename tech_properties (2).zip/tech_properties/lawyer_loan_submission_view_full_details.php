<?php
session_start();
include 'config.php';

if (!isset($_SESSION['lawyer_id'])) {
    header("Location: lawyer_login.php");
    exit();
}

if (isset($_GET['submission_id'])) {
    $submission_id = $_GET['submission_id'];

    $query = "
        SELECT 
            ls.*, 
            u.user_fullname, 
            a.ren_number, 
            b.bank_id, 
            b.bank_name, 
            p.title, 
            p.location, 
            p.type, 
            p.price 
        FROM 
            loan_submissions ls 
        JOIN 
            users u ON ls.user_id = u.user_id
        JOIN 
            properties p ON ls.property_id = p.property_id
        JOIN 
            bankers b ON ls.banker_id = b.banker_id
        JOIN 
            agents a ON ls.agent_id = a.agent_id
        WHERE 
            ls.submission_id = ?
    ";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $submission_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $details = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Submission Details</title>
 <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="lawyer_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
        <div>rrr</div>

<div class="container mt-5">
    <h2>Loan Submission Details</h2>
    <table class="table">
        <tr>
            <th>User Full Name:</th>
            <td><?php echo htmlspecialchars($details['user_fullname']); ?></td>
        </tr>
        <tr>
            <th>REN Number:</th>
            <td><?php echo htmlspecialchars($details['ren_number']); ?></td>
        </tr>
        <tr>
            <th>Bank ID:</th>
            <td><?php echo htmlspecialchars($details['bank_id']); ?></td>
        </tr>
        <tr>
            <th>Bank Name:</th>
            <td><?php echo htmlspecialchars($details['bank_name']); ?></td>
        </tr>
        
        <tr>
            <th>Property Title:</th>
            <td><?php echo htmlspecialchars($details['title']); ?></td>
        </tr>
        <tr>
            <th>Location:</th>
            <td><?php echo htmlspecialchars($details['location']); ?></td>
        </tr>
        <tr>
            <th>Type:</th>
            <td><?php echo htmlspecialchars($details['type']); ?></td>
        </tr>
        <tr>
            <th>Price:</th>
            <td><?php echo htmlspecialchars($details['price']); ?></td>
        </tr>
        <tr>
            <th>Created At:</th>
            <td><?php echo htmlspecialchars($details['created_at']); ?></td>
        </tr>
        <tr>
                        <th>ID Proof</th>
                        <td><a href="<?php echo htmlspecialchars($details['id_proof']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>EPF Statements</th>
                        <td><a href="<?php echo htmlspecialchars($details['epf_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Bank Statements</th>
                        <td><a href="<?php echo htmlspecialchars($details['bank_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Payslips</th>
                        <td><a href="<?php echo htmlspecialchars($details['payslips']); ?>" target="_blank">View Document</a></td>
                    </tr>
    </table>
    <a href="lawyer_appointment_sign_in.php" class="btn btn-primary">Back to Approved Submissions</a>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
