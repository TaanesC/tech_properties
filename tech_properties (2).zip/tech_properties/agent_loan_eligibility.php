<?php
session_start();
include 'config.php'; 

$agent_id = $_SESSION['agent_id']; 

// Prepare the SQL query
$query = "SELECT le.eligibility_id , u.user_fullname, le.id_proof, p.title, p.location, p.type, p.price, le.created_at 
          FROM loan_eligibility le 
          JOIN users u ON le.user_id = u.user_id 
          JOIN properties p ON le.property_id = p.property_id 
          WHERE le.agent_id = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("MySQL prepare error: " . htmlspecialchars($conn->error));
}

$stmt->bind_param("i", $agent_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Eligibility Requests</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
    <div>rrr</div>
    <div>rrr</div>
<div class="container">
    <h2>Loan Eligibility Requests</h2>
    <table class="table">
        <thead>
            <tr>
                <th>User Full Name</th>
                <th>ID Proof</th>
                <th>Title</th>
                <th>Location</th>
                <th>Type</th>
                <th>Price</th>
                <th>Created Date</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) : ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['user_fullname']); ?></td>
                    <td><a href="<?php echo htmlspecialchars($row['id_proof']); ?>" target="_blank">View Document</a></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['location']); ?></td>
                    <td><?php echo htmlspecialchars($row['type']); ?></td>
                    <td><?php echo htmlspecialchars($row['price']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                    <td>
                        <a href="agent_loan_eligibility_view_full_details.php?eligibility_id=<?php echo $row['eligibility_id']; ?>" class="btn btn-info">View Full Details</a>
                        <a href="agent_loan_eligibility_eligible.php?eligibility_id=<?php echo $row['eligibility_id']; ?>" class="btn btn-success">Eligible</a>
                        <a href="agent_loan_eligibility_not_eligible.php?eligibility_id=<?php echo $row['eligibility_id']; ?>" class="btn btn-danger">Not Eligible</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
<script src="path/to/bootstrap.js"></script> 
</body>
</html>


