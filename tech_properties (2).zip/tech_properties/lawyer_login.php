<?php
session_start();
require 'config.php';

if (isset($_POST['login'])) {
    $firm_number = $_POST['firm_number'];
    $lawyer_password = $_POST['lawyer_password'];

    // Check if lawyer exists
    $query = "SELECT * FROM lawyers WHERE firm_number = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('s', $firm_number);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $lawyer = $result->fetch_assoc();
        if (password_verify($lawyer_password, $lawyer['lawyer_password'])) {
            $_SESSION['lawyer_id'] = $lawyer['lawyer_id'];
            header('Location: lawyer_dashboard.php');
            exit();
        } else {
            $error_message = "Invalid firm number or password!";
        }
    } else {
        $error_message = "Lawyer not found!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lawyer Login | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f7f7f7;
        }
        .container {
            max-width: 400px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header-title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .navbar {
            background-color: #001f3f;
            padding: 20px;
            width: 100%;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">TECH PROPERTIES</a>
    </nav>

    <div class="container mt-4">
        <div class="header-title">Lawyer Login</div>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <form action="" method="POST">
            <div class="mb-3">
                <label for="firm_number" class="form-label">Firm Number</label>
                <input type="text" class="form-control" id="firm_number" name="firm_number" required>
            </div>
            <div class="mb-3">
                <label for="lawyer_password" class="form-label">Password</label>
                <input type="password" class="form-control" id="lawyer_password" name="lawyer_password" required>
            </div>
            <button type="submit" name="login" class="btn btn-primary w-100">Login</button>
        </form>
    </div>
</body>
</html>

