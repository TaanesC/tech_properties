<?php
session_start();
require 'config.php'; 


if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];


$property_id = isset($_GET['property_id']) ? $_GET['property_id'] : null;
if (!$property_id) {
    echo "Property ID is missing!";
    exit();
}


$sql = "SELECT * FROM properties WHERE property_id = ? AND agent_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("is", $property_id, $agent_id);
$stmt->execute();
$result = $stmt->get_result();
$property = $result->fetch_assoc();
$stmt->close();

if (!$property) {
    echo "Property not found or access denied!";
    exit();
}


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $price = $_POST['price'];
    $location = $_POST['location'];
    $type = $_POST['type'];
    $rent_or_sale = $_POST['rent_or_sale'];

    
    if (isset($_FILES['cover_pic']) && $_FILES['cover_pic']['error'] === UPLOAD_ERR_OK) {
        $cover_pic = $_FILES['cover_pic'];
        $image_name = basename($cover_pic['name']);
        $image_path = 'uploads/' . $image_name;

        
        move_uploaded_file($cover_pic['tmp_name'], $image_path);

        
        $sql = "UPDATE properties SET title = ?, price = ?, location = ?, type = ?, rent_or_sale = ?, cover_pic = ? WHERE property_id = ? AND agent_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sisssssi", $title, $price, $location, $type, $rent_or_sale, $image_path, $property_id, $agent_id);
    } else {
        
        $sql = "UPDATE properties SET title = ?, price = ?, location = ?, type = ?, rent_or_sale = ? WHERE property_id = ? AND agent_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sissssi", $title, $price, $location, $type, $rent_or_sale, $property_id, $agent_id);
    }

    
    if ($stmt->execute()) {
        echo "Property updated successfully!";
        header("Location: agent_property_management.php"); 
        exit();
    } else {
        echo "Error updating property: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Property - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%; 
            padding: 20px;
            position: fixed; 
            top: 0;
            left: 0;
            z-index: 1000; 
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container mt-5">
        <h1>Edit Property</h1>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="title" class="form-label">Title</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($property['title']); ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="price" class="form-label">Price</label>
                <input type="number" class="form-control" id="price" name="price" value="<?php echo htmlspecialchars($property['price']); ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" class="form-control" id="location" name="location" value="<?php echo htmlspecialchars($property['location']); ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="type" class="form-label">Type</label>
                <input type="text" class="form-control" id="type" name="type" value="<?php echo htmlspecialchars($property['type']); ?>" required>
            </div>
            
            <div class="mb-3">
                <label for="rent_or_sale" class="form-label">For Rent/Sale</label>
                <select class="form-select" id="rent_or_sale" name="rent_or_sale" required>
                    <option value="for_rent" <?php echo ($property['rent_or_sale'] == 'for_rent') ? 'selected' : ''; ?>>For Rent</option>
                    <option value="for_sale" <?php echo ($property['rent_or_sale'] == 'for_sale') ? 'selected' : ''; ?>>For Sale</option>
                </select>
            </div>
            
            <div class="mb-3">
                <label for="cover_pic" class="form-label">Cover Image</label>
                <input type="file" class="form-control" id="cover_pic" name="cover_pic">
                <?php if ($property['cover_pic']): ?>
                    <img src="<?php echo htmlspecialchars($property['cover_pic']); ?>" alt="Cover Image" style="width: 100px; height: auto; margin-top: 10px;">
                <?php endif; ?>
            </div>
            
            <button type="submit" class="btn btn-primary">Update Property</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>




