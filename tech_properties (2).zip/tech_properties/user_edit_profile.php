<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT user_fullname, user_email, user_phonenumber, user_age, user_occupation, profile_pic FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_fullname = $_POST['user_fullname'];
    $user_email = $_POST['user_email'];
    $user_phonenumber = $_POST['user_phonenumber'];
    $user_age = $_POST['user_age'];
    $user_occupation = $_POST['user_occupation'];

    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/"; // Directory where profile pictures are uploaded
        $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

        $check = getimagesize($_FILES["profile_pic"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }

        if ($_FILES["profile_pic"]["size"] > 5000000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }

        if (!in_array($imageFileType, ['jpg', 'png', 'jpeg', 'gif'])) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }

        if ($uploadOk === 1) {
            if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                // Update the user profile in the database
                $query = "UPDATE users SET user_fullname = ?, user_email = ?, user_phonenumber = ?, user_age = ?, user_occupation = ?, profile_pic = ? WHERE user_id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('sssissi', $user_fullname, $user_email, $user_phonenumber, $user_age, $user_occupation, $target_file, $user_id);
                $stmt->execute();
                header('Location: user_dashboard.php');
                exit();
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        }
    } else {
        $query = "UPDATE users SET user_fullname = ?, user_email = ?, user_phonenumber = ?, user_age = ?, user_occupation = ? WHERE user_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sssisi', $user_fullname, $user_email, $user_phonenumber, $user_age, $user_occupation, $user_id);
        $stmt->execute();
        header('Location: user_dashboard.php');
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
        }
        .container {
            max-width: 600px;
            margin-top: 30px;
            background-color: white;
            padding: 80px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="user_dashboard.php">TECH PROPERTIES</a>
    </nav>

    <div class="container mt-5">
        <h2>Edit Profile</h2>

        <form action="" method="POST" enctype="multipart/form-data">
             <div class="mb-3">
                <label for="user_fullname" class="form-label">User Fullname</label>
                <input type="text" class="form-control" id="user_fullname" name="user_fullname" value="<?php echo $user['user_fullname']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="user_email" class="form-label">Email address</label>
                <input type="email" class="form-control" id="user_email" name="user_email" value="<?php echo $user['user_email']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="user_phonenumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="user_phonenumber" name="user_phonenumber" value="<?php echo $user['user_phonenumber']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="user_age" class="form-label">Age</label>
                <input type="number" class="form-control" id="user_age" name="user_age" value="<?php echo $user['user_age']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="user_occupation" class="form-label">Occupation</label>
                <input type="text" class="form-control" id="user_occupation" name="user_occupation" value="<?php echo $user['user_occupation']; ?>" required>
            </div>
            <div class="mb-3">
                <label for="profile_pic" class="form-label">Profile Picture</label>
                <input type="file" class="form-control" id="profile_pic" name="profile_pic" accept="image/*">
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>

        <div class="mt-3">
            <a href="user_change_password.php" class="btn btn-secondary">Change Password</a>
        </div>
    </div>

</body>
</html>


