<?php
// Database connection
require 'config.php';

// Fetch latest approved properties for display
$properties = [];
$query = "SELECT * FROM properties WHERE status = 'approved' ORDER BY created_at DESC LIMIT 9";
$result = $conn->query($query);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $properties[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Navbar styling */
        .navbar {
            background-color: #001f3f;
            padding: 20px;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        /* Page content styling */
        .content {
            margin-top: 80px;
            padding: 20px;
        }
        .property-card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: transform 0.2s;
        }
        .property-card:hover {
            transform: translateY(-5px);
        }
        .property-card img {
            width: 100%;
            height: 180px;
            border-radius: 8px;
        }
        .property-title {
            font-weight: bold;
            font-size: 18px;
        }
        .property-info {
            margin-top: 10px;
            color: #555;
        }
        .btn-view-details {
            background-color: #001f3f;
            color: #fff;
            border: none;
            width: 100%;
        }
        .filter-sort-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="#">TECH PROPERTIES</a>
</nav>

<div class="content container">
    <!-- Search and Filter Section -->
    <div class="filter-sort-bar">
        <form class="d-flex flex-wrap" method="GET" action="homepage.php">
            <input class="form-control me-2" type="search" name="search" placeholder="Search by location..." aria-label="Search" style="max-width: 200px;">
            <select class="form-select me-2" name="type">
                <option value="">Type</option>
                <option value="House">House</option>
                <option value="Apartment">Apartment</option>
                <option value="Condo">Condo</option>
            </select>
            <select class="form-select me-2" name="rent_or_sale">
                <option value="">Rent/Sale</option>
                <option value="rent">Rent</option>
                <option value="sale">Sale</option>
            </select>
            <select class="form-select me-2" name="sort_price">
                <option value="">Sort by Price</option>
                <option value="low_to_high">Low to High</option>
                <option value="high_to_low">High to Low</option>
            </select>
            <button class="btn btn-primary" type="submit">Apply Filters</button>
        </form>
    </div>

    <!-- Properties Display Section -->
    <div class="row g-4">
        <?php foreach ($properties as $property): ?>
            <div class="col-md-4">
                <div class="property-card">
                    <img src="uploads/<?php echo $property['cover_pic']; ?>" alt="Property Cover Image">
                    <div class="property-info mt-3">
                        <h5 class="property-title"><?php echo $property['title']; ?></h5>
                        <p class="mb-1"><strong>Price:</strong> RM <?php echo number_format($property['price']); ?></p>
                        <p class="mb-1"><strong>Location:</strong> <?php echo $property['location']; ?></p>
                        <p class="mb-1"><strong>Type:</strong> <?php echo $property['type']; ?></p>
                        <p class="mb-1"><strong>Status:</strong> <?php echo ucfirst($property['rent_or_sale']); ?></p>
                        <p class="mb-1">
                            <i class="fas fa-ruler-combined"></i> <?php echo $property['sqft']; ?> sqft
                            <i class="fas fa-bed ms-3"></i> <?php echo $property['bedrooms']; ?> Beds
                            <i class="fas fa-bath ms-3"></i> <?php echo $property['bathrooms']; ?> Baths
                        </p>
                    </div>
                    <a href="property_details.php?id=<?php echo $property['property_id']; ?>" class="btn btn-view-details mt-3">View Full Details</a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- FontAwesome for Icons -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



