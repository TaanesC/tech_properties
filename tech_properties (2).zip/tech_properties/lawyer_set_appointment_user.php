<?php
session_start();
include 'config.php';

if (!isset($_SESSION['lawyer_id'])) {
    header("Location: lawyer_login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the data from the form
    $user_id = $_POST['user_id'];
    $agent_id = $_POST['agent_id'];
    $property_id = $_POST['property_id']; 
    $lawyer_id = $_SESSION['lawyer_id'];
    $banker_id = $_POST['banker_id']; 
    
    $appointment_date = $_POST['appointment_date'] . ' ' . $_POST['appointment_time'];

    $stmt = $conn->prepare("INSERT INTO appointments (user_id, agent_id, property_id, lawyer_id, banker_id, appointment_date) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiiis", $user_id, $agent_id, $property_id, $lawyer_id, $banker_id, $appointment_date);

    if ($stmt->execute()) {
        echo "<div class='alert alert-success'>Appointment set successfully!</div>";
    } else {
        echo "<div class='alert alert-danger'>Error setting appointment: " . $stmt->error . "</div>";
    }

    $stmt->close();
}

if (isset($_GET['submission_id'])) {
    $submission_id = $_GET['submission_id'];
    $query = "SELECT u.user_id, u.user_fullname, a.agent_id, ls.property_id, ls.banker_id
              FROM loan_submissions ls 
              JOIN users u ON ls.user_id = u.user_id 
              JOIN agents a ON ls.agent_id = a.agent_id 
              WHERE ls.submission_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $submission_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $details = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Set Appointment</title>
</head>
<body>

<div class="container mt-5">
    <h2>Set Appointment</h2>
    <form action="" method="POST">
        <input type="hidden" name="user_id" value="<?php echo htmlspecialchars($details['user_id']); ?>">
        <input type="hidden" name="agent_id" value="<?php echo htmlspecialchars($details['agent_id']); ?>">
        <input type="hidden" name="property_id" value="<?php echo htmlspecialchars($details['property_id']); ?>">
        <input type="hidden" name="banker_id" value="<?php echo htmlspecialchars($details['banker_id']); ?>">

        <div class="form-group">
            <label for="appointment_date">Select Date:</label>
            <input type="date" class="form-control" name="appointment_date" required>
        </div>
        <div class="form-group">
            <label for="appointment_time">Select Time:</label>
            <input type="time" class="form-control" name="appointment_time" required>
        </div>
        <button type="submit" class="btn btn-primary">Set Appointment</button>
    </form>
    <a href="lawyer_appointment_sign_in.php" class="btn btn-secondary">Cancel</a>
</div>

</body>
</html>

<?php
$conn->close();
?>




