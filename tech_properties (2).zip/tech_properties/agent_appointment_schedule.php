<?php
session_start();
require 'config.php'; 

// Check if agent is logged in
if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php'); 
    exit();
}

$agent_id = $_SESSION['agent_id'];

// Query to fetch appointments
$query = "
    SELECT a.appointment_id, u.user_fullname, p.title, p.location, p.type, p.price, 
           a.appointment_date, a.appointment_status, a.created_at 
    FROM appointments a 
    JOIN users u ON a.user_id = u.user_id 
    JOIN properties p ON a.property_id = p.property_id 
    WHERE a.agent_id = ?
";

$stmt = $conn->prepare($query);
$stmt->bind_param('i', $agent_id);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Schedule | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rr</div>
        <div>rr</div>

    <div class="container mt-4">
        <h2>Appointment Schedule</h2>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Property Title</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Created At</th>
                    <th>Appointment Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['user_fullname']); ?></td>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['location']); ?></td>
                            <td><?php echo htmlspecialchars($row['type']); ?></td>
                            <td><?php echo htmlspecialchars($row['price']); ?></td>
                            <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                            <td><?php echo htmlspecialchars($row['appointment_date']); ?></td>
                            <td><?php echo htmlspecialchars($row['appointment_status']); ?></td>
                            <td>
                                <a href="agent_appointment_schedule_confirmed.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="btn btn-success btn-sm">Confirm</a>
                                <a href="agent_appointment_schedule_reshcedule.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="btn btn-warning btn-sm">Reschedule</a>
                                <a href="agent_appointment_schedule_cancel.php?appointment_id=<?php echo $row['appointment_id']; ?>" class="btn btn-danger btn-sm">Cancel</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="9" class="text-center">No appointments found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>


