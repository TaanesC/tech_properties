<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "SELECT a.appointment_id, a.agent_id, a.lawyer_id, a.appointment_date, a.appointment_status, 
          p.title, p.location, p.type, p.price, a.created_at, 
          CONCAT_WS(' ', ag.agent_fullname, l.lawyer_fullname) AS full_name
          FROM appointments AS a 
          LEFT JOIN properties AS p ON a.property_id = p.property_id
          LEFT JOIN agents AS ag ON a.agent_id = ag.agent_id
          LEFT JOIN lawyers AS l ON a.lawyer_id = l.lawyer_id
          WHERE a.user_id = ? ORDER BY a.created_at DESC";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("Error preparing the SQL statement: " . $conn->error);
}

$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

$appointments = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Appointments | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
    .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        
        </style>

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="user_dashboard.php">TECH PROPERTIES</a>
    </nav>
    
    <div>rrrrrrrr</div>
    <div>a</div>

    <div class="container mt-4">
        <h2>Your Appointments</h2>
        <div class="mb-3">
            <label for="filter" class="form-label">Filter by:</label>
            <select id="filter" class="form-select" onchange="filterAppointments(this.value)">
                <option value="all">All</option>
                <option value="agents">Agents</option>
                <option value="lawyers">Lawyers</option>
            </select>
        </div>
        
        <table class="table">
            <thead>
                <tr>
                    <th>Full Name</th>
                    <th>Property Title</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Created At</th>
                    <th>Appointment Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="appointment-table">
                <?php foreach ($appointments as $appointment): ?>
                    <tr class="appointment-row" data-type="<?= $appointment['agent_id'] ? 'agents' : 'lawyers' ?>">
                        <td><?= htmlspecialchars($appointment['full_name']) ?></td>
                        <td><?= htmlspecialchars($appointment['title']) ?></td>
                        <td><?= htmlspecialchars($appointment['location']) ?></td>
                        <td><?= htmlspecialchars($appointment['type']) ?></td>
                        <td><?= htmlspecialchars($appointment['price']) ?></td>
                        <td><?= htmlspecialchars($appointment['created_at']) ?></td>
                        <td><?= htmlspecialchars($appointment['appointment_date']) ?></td>
                        <td><?= htmlspecialchars($appointment['appointment_status']) ?></td>
                        <td>
                            <?php if ($appointment['lawyer_id'] && $appointment['appointment_status'] === 'pending'): ?>
                            <a href="user_appointment_schedule_confirmed.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-success">Confirm</a>
                            <a href="user_appointment_schedule_reschedule.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-warning">Reschedule</a>
                            <a href="user_appointment_schedule_cancel.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-danger">Cancel</a>
                        <?php elseif (!$appointment['lawyer_id'] && $appointment['appointment_status'] === 'pending'): ?>
                            <a href="user_appointment_schedule_cancel.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-danger">Cancel</a>
                        <?php elseif ($appointment['appointment_status'] === 'rescheduled'): ?>
                            <a href="user_appointment_schedule_confirmed.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-success">Confirm</a>
                            <a href="user_appointment_schedule_cancel.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-danger">Cancel</a>
                        <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script>
        function filterAppointments(type) {
            const rows = document.querySelectorAll('.appointment-row');
            rows.forEach(row => {
                if (type === 'all' || row.getAttribute('data-type') === type) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>