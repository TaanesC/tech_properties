<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['agent_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];
$agreement_id = $_POST['agreement_id'];
$signed_agreement = $_FILES['signed_agreement'];




$upload_dir = 'landlord_signed_agreement_pdf/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Validate and save the uploaded file
if ($signed_agreement['error'] == 0 && in_array($signed_agreement['type'], ['application/pdf'])) {
    $file_path = $upload_dir . basename($signed_agreement['name']); // Keep the original filename
    if (move_uploaded_file($signed_agreement['tmp_name'], $file_path)) {
        
        // Prepare the SQL query
        $query = "
            UPDATE tenancy_agreements 
            SET landlord_signed_agreement_pdf = ? 
            WHERE agreement_id = ? AND agent_id = ?
        ";
        $stmt = $conn->prepare($query);

        // Check if prepare() was successful
        if ($stmt === false) {
            die("Error preparing query: " . $conn->error);
        }

        $stmt->bind_param('sii', $file_path, $agreement_id, $agent_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            header('Location: agent_tenancy_agreement_management.php?upload=success');
        } else {
            echo "Failed to update record. Please try again.";
        }

        $stmt->close();
    } else {
        echo "Failed to upload file.";
    }
} else {
    echo "Invalid file type. Please upload a PDF document.";
}
?>



















