<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];

if (!isset($_GET['token'])) {
    die('Token is missing!');
}

$token = $_GET['token'];

$query = "
    SELECT m.message_id, m.token, m.sender, m.receiver, m.message_text, m.created_at, 
           p.property_id, p.title AS property_title, p.rent_or_sale, u.user_id, u.user_fullname
    FROM messages m
    LEFT JOIN users u ON m.user_id = u.user_id
    LEFT JOIN properties p ON m.property_id = p.property_id
    WHERE m.token = ? AND (m.agent_id = ? OR m.user_id = u.user_id)
    ORDER BY m.created_at ASC
";

$stmt = $conn->prepare($query);
if ($stmt === false) {
    die('MySQL prepare error: ' . $conn->error);
}

$stmt->bind_param('si', $token, $agent_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die('No conversation found.');
}

$conversation = $result->fetch_all(MYSQLI_ASSOC);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $message_text = $_POST['message_text'];

    if (!empty($message_text)) {
        $insert_query = "
            INSERT INTO messages (user_id, agent_id, sender, receiver, message_text, property_id, token)
            VALUES (?, ?, 'agent', 'user', ?, ?, ?)
        ";

        $stmt_insert = $conn->prepare($insert_query);
        if ($stmt_insert === false) {
            die('MySQL prepare error: ' . $conn->error);
        }

        $user_id = $conversation[0]['user_id'];  
        $property_id = $conversation[0]['property_id'];  

        $stmt_insert->bind_param('iisss', $user_id, $agent_id, $message_text, $property_id, $token);
        $stmt_insert->execute();

        header("Location: agent_message_user.php?token=$token");
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Message with User</title>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    
    <style>
.navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
    </style>
</head>
<body>
<div class="container mt-4">
    <h3>Chat with Agent - <?= htmlspecialchars($conversation[0]['user_fullname']) ?></h3>
    <h5>Property: <?= htmlspecialchars($conversation[0]['property_title']) ?> (<?= htmlspecialchars($conversation[0]['rent_or_sale']) ?>)</h5>
    
    <div class="card mt-3">
        <div class="card-body" style="height: 400px; overflow-y: scroll;">
            <?php if ($conversation): ?>
                <?php foreach ($conversation as $msg): ?>
                    <?php if ($msg['sender'] == 'agent'): ?>
                        <div class="d-flex justify-content-end mb-3">
                            <div class="bg-secondary text-white p-2 rounded">
                                <strong>You:</strong> <?= htmlspecialchars($msg['message_text']) ?>
                                <br><small><?= date('Y-m-d H:i:s', strtotime($msg['created_at'])) ?></small>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="d-flex justify-content-start mb-3">
                            <div class="bg-primary text-white p-2 rounded">
                                <strong><?= htmlspecialchars($conversation[0]['user_fullname']) ?>:</strong> <?= htmlspecialchars($msg['message_text']) ?>
                                <br><small><?= date('Y-m-d H:i:s', strtotime($msg['created_at'])) ?></small>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No messages yet. Start the conversation!</p>
            <?php endif; ?>
        </div>
    </div>

<form method="POST" action="" class="mt-4">
        <div class="input-group">
            <input type="text" name="message_text" class="form-control" placeholder="Type your message here..." required>
            <button type="submit" class="btn btn-primary">Send</button>
        </div>
    </form>

        <!-- Create tenancy agreement button -->
        <a href="create_tenancy_agreement_form.php?token=<?php echo $conversation[0]['token']; ?>" class="btn btn-success mt-3">Create Tenancy Agreement</a>
    
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>






