<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

if (isset($_GET['property_id'])) {
    $property_id = $_GET['property_id'];

    $stmt = $conn->prepare("SELECT * FROM properties WHERE property_id = ? AND agent_id = ?");
    $stmt->bind_param("ss", $property_id, $_SESSION['agent_id']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $property = $result->fetch_assoc();
    } else {
        echo "Property not found or you do not have permission to view this property.";
        exit();
    }
} else {
    echo "No property ID provided.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Property Details - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
      .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 70px; 
        }
        .property-image {
            width: 100%;
            height: auto;
            max-height: 400px;
            object-fit: cover;
        }
        .card {
            border: none; 
            border-radius: 8px; 
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); 
        }
        h1 {
            color: #001f3f; 
        }
        h3 {
            color: #333; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">View Property Details</h1>

        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title"><?php echo htmlspecialchars($property['title']); ?></h3>
                <p class="card-text"><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($property['description'])); ?></p>
                <p class="card-text"><strong>Price:</strong> RM <?php echo htmlspecialchars(number_format($property['price'], 2)); ?></p>
                <p class="card-text"><strong>Location:</strong> <?php echo htmlspecialchars($property['location']); ?></p>
                <p class="card-text"><strong>Type:</strong> <?php echo htmlspecialchars($property['type']); ?></p>
                <p class="card-text"><strong>For:</strong> <?php echo htmlspecialchars($property['rent_or_sale']); ?></p>
                <p class="card-text"><strong>Square Feet:</strong> <?php echo htmlspecialchars($property['sqft']); ?></p>
                <p class="card-text"><strong>Bedrooms:</strong> <?php echo htmlspecialchars($property['bedrooms']); ?></p>
                <p class="card-text"><strong>Bathrooms:</strong> <?php echo htmlspecialchars($property['bathrooms']); ?></p>
                <p class="card-text"><strong>Status:</strong> <?php echo htmlspecialchars($property['status']); ?></p>
                <p class="card-text"><strong>Created At:</strong> <?php echo htmlspecialchars(date('d-m-Y', strtotime($property['created_at']))); ?></p>

                <?php if (!empty($property['cover_pic'])): ?>
                    <h5>Cover Picture:</h5>
                    <img src="<?php echo htmlspecialchars($property['cover_pic']); ?>" alt="Cover Picture" class="property-image mb-3">
                <?php endif; ?>

                <h5>Additional Pictures:</h5>
                <div class="row">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <?php $pic = 'additional_pic_' . $i; ?>
                        <?php if (!empty($property[$pic])): ?>
                            <div class="col-12 col-md-4 mb-3">
                                <img src="<?php echo htmlspecialchars($property[$pic]); ?>" alt="Additional Picture <?php echo $i; ?>" class="property-image">
                            </div>
                        <?php endif; ?>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



