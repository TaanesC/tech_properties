<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

if (isset($_POST['update_status'])) {
    $property_id = $_POST['property_id'];
    
    $query = "SELECT rent_or_sale FROM properties WHERE property_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $property_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $property = $result->fetch_assoc();
        
        // Determine new status based on rent_or_sale
        if ($property['rent_or_sale'] == 'for_sale') {
            $new_status = 'sold';
        } elseif ($property['rent_or_sale'] == 'for_rent') {
            $new_status = 'rented';
        } else {
            $new_status = 'available'; 
        }

        $updateQuery = "UPDATE properties SET rented_or_sold = ? WHERE property_id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param('si', $new_status, $property_id);
        
        if ($updateStmt->execute()) {
            $success_message = "Property status updated to " . htmlspecialchars($new_status) . ".";
        } else {
            $error_message = "Failed to update property status.";
        }
    } else {
        $error_message = "Property not found.";
    }
}

$query = "SELECT property_id, title, price, location, rent_or_sale FROM properties WHERE agent_id = ? AND rented_or_sold = 'available'";
$stmt = $conn->prepare($query);
$stmt->bind_param('s', $_SESSION['agent_id']);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Sold/Rented Properties | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            padding: 20px;
            width: 100%;
            position: fixed;
            top: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
    </nav>

    <!-- Main content -->
    <div class="container content">
        <h2 class="mt-4 mb-4">Manage Sold/Rented Properties</h2>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php elseif (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Property ID</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($property = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($property['property_id']); ?></td>
                            <td><?php echo htmlspecialchars($property['title']); ?></td>
                            <td><?php echo htmlspecialchars($property['price']); ?></td>
                            <td><?php echo htmlspecialchars($property['location']); ?></td>
                            <td><?php echo htmlspecialchars($property['rent_or_sale']); ?></td>
                            <td>
                                <form action="" method="POST" class="d-inline">
                                    <input type="hidden" name="property_id" value="<?php echo $property['property_id']; ?>">
                                    <button type="submit" name="update_status" class="btn btn-warning btn-sm" 
                                            onclick="return confirm('Are you sure you want to mark this property as sold or rented?');">
                                        Mark as Sold/Rented
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No available properties found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>





