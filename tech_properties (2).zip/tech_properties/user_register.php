<?php
session_start();
require 'config.php';

// Debugging
if (!$conn) {
    die("Database connection failed.");
}

// Handle form submission
if (isset($_POST['register'])) {
    $user_email = $_POST['user_email'];
    $user_phonenumber = $_POST['user_phonenumber'];
    $user_password = $_POST['user_password'];
    $user_confirm_password = $_POST['user_confirm_password'];

    // Check if passwords match
    if ($user_password !== $user_confirm_password) {
        $error_message = "Passwords do not match!";
    } else {
        // Hash the password
        $hashed_password = password_hash($user_password, PASSWORD_DEFAULT);

        // Insert user into the database
        $query = "INSERT INTO users (user_email, user_phonenumber, user_password) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sss', $user_email, $user_phonenumber, $hashed_password);

        if ($stmt->execute()) {
            $_SESSION['user_id'] = $conn->insert_id; 
            header('Location: user_dashboard.php');
            exit();
        } else {
            $error_message = "Registration failed! Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Registration | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f7f7f7;
        }
        .container {
            max-width: 400px;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .header-title {
            font-size: 24px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 20px;
        }
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">TECH PROPERTIES</a>
    </nav>

    <div class="container mt-4">
        <div class="header-title">User Registration</div>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>
        
        <form action="" method="POST">
            <div class="mb-3">
                <label for="user_email" class="form-label">Email Address</label>
                <input type="email" class="form-control" id="user_email" name="user_email" required>
            </div>
            <div class="mb-3">
                <label for="user_phonenumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="user_phonenumber" name="user_phonenumber" required>
            </div>
            <div class="mb-3">
                <label for="user_password" class="form-label">Password</label>
                <input type="password" class="form-control" id="user_password" name="user_password" required>
            </div>
            <div class="mb-3">
                <label for="user_confirm_password" class="form-label">Confirm Password</label>
                <input type="password" class="form-control" id="user_confirm_password" name="user_confirm_password" required>
            </div>
            <button type="submit" name="register" class="btn btn-primary w-100">Register</button>
        </form>

        <div class="mt-3 text-center">
            <p class="mb-0">Already registered? <a href="user_login.php">Login here</a></p>
        </div>
    </div>

</body>
</html>


