<?php
session_start();
include 'config.php';

$id = $_GET['eligibility_id'];
$query = "SELECT le.*, u.user_fullname, p.title, p.location, p.type, p.price 
          FROM loan_eligibility le 
          JOIN users u ON le.user_id = u.user_id 
          JOIN properties p ON le.property_id = p.property_id 
          WHERE le.eligibility_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Loan Eligibility Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            padding: 20px;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .container {
            margin-top: 80px; 
        }
        .card {
            margin-top: 20px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            background-color: #007bff;
            color: white;
            font-weight: bold;
        }
        .document-link {
            color: #007bff;
            text-decoration: underline;
        }
        .document-link:hover {
            text-decoration: none;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>

<div class="container">
    <div class="card">
        <div class="card-header">
            Loan Eligibility Details for <?php echo htmlspecialchars($row['user_fullname']); ?>
        </div>
        <div class="card-body">
            <p><strong>ID Proof:</strong> <a class="document-link" href="<?php echo htmlspecialchars($row['id_proof']); ?>" target="_blank">View Document</a></p>
            <p><strong>EPF Statement:</strong> <a class="document-link" href="<?php echo htmlspecialchars($row['epf_statements']); ?>" target="_blank">View Document</a></p>
            <p><strong>Bank Statements:</strong> <a class="document-link" href="<?php echo htmlspecialchars($row['bank_statements']); ?>" target="_blank">View Document</a></p>
            <p><strong>Payslips:</strong> <a class="document-link" href="<?php echo htmlspecialchars($row['payslips']); ?>" target="_blank">View Document</a></p>

            <hr>

            <p><strong>Property Title:</strong> <?php echo htmlspecialchars($row['title']); ?></p>
            <p><strong>Location:</strong> <?php echo htmlspecialchars($row['location']); ?></p>
            <p><strong>Type:</strong> <?php echo htmlspecialchars($row['type']); ?></p>
            <p><strong>Price:</strong> RM <?php echo htmlspecialchars(number_format($row['price'], 2)); ?></p>
            <p><strong>Created At:</strong> <?php echo htmlspecialchars(date('d M Y, H:i', strtotime($row['created_at']))); ?></p>
            <p><strong>Eligibility Status:</strong> <?php echo htmlspecialchars($row['eligibility_status']); ?></p>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


