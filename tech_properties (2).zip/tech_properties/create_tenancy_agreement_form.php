<?php
require_once 'config.php';
require 'fpdf.php';
session_start();

if (!isset($_SESSION['agent_id'])) {
    header('Location: login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];

if (!isset($_GET['token'])) {
    die('Token is missing!');
}

$token = $_GET['token'];

$query = "
    SELECT m.property_id, m.user_id
    FROM messages m
    LEFT JOIN users u ON m.user_id = u.user_id
    WHERE m.token = ?
    LIMIT 1
";

$stmt = $conn->prepare($query);
$stmt->bind_param('s', $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die('No property or user found for this token.');
}

$data = $result->fetch_assoc();
$property_id = $data['property_id'];
$user_id = $data['user_id'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $landlord_fullname = $_POST['landlord_fullname'];
    $landlord_ic = $_POST['landlord_ic'];
    $landlord_address = $_POST['landlord_address'];
    $tenant_fullname = $_POST['tenant_fullname'];
    $tenant_ic = $_POST['tenant_ic'];
    $tenant_address = $_POST['tenant_address'];
    $property_address = $_POST['property_address'];
    $monthly_rental = $_POST['monthly_rental'];
    $deposit = $_POST['deposit'];
    $rental_start_date = $_POST['rental_start_date'];
    $rental_end_date = $_POST['rental_end_date'];
    $contract_period = $_POST['contract_period'];
    $created_at = date('Y-m-d');

    // Generate PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16); 
    $pdf->Cell(0, 10, 'CONTRACT OF TENANCY AGREEMENT', 0, 1, 'C');
    $pdf->Ln(10);

    $pdf->SetFont('Arial', '', 12);
    $pdf->MultiCell(0, 10, "
        $property_address
        Date: $created_at
        
        In consideration of the agreements of the Resident(s), known as:
        $tenant_fullname
        NRIC No. $tenant_ic
        $tenant_address

        And the owner known as:
        $landlord_fullname
        NRIC No. $landlord_ic
        $landlord_address

        For the period commencing on the $rental_start_date and monthly thereafter until the last day of $rental_end_date ($contract_period) at which time this Agreement is terminated. Resident(s), in consideration of owners permitting them to occupy the above property, hereby agrees to the following terms:
        
        MONTHLY RENTAL RATE RM $monthly_rental
        RENTAL DEPOSIT RM $deposit
    ");
    
    $pdf->Ln(10);
    $pdf->Cell(0, 10, "Resident's signature", 0, 1);
    $pdf->Cell(0, 10, "____________________________", 0, 1);
    $pdf->Cell(0, 10, "$tenant_fullname", 0, 1);
    $pdf->Cell(0, 10, "NRIC No. $tenant_ic", 0, 1);
    
    $pdf->Ln(10);
    $pdf->Cell(0, 10, "Landlord's signature", 0, 1);
    $pdf->Cell(0, 10, "____________________________", 0, 1);
    $pdf->Cell(0, 10, "$landlord_fullname", 0, 1);
    $pdf->Cell(0, 10, "NRIC No. $landlord_ic", 0, 1);

    // Save PDF file
    $pdf_filename = "agreement_pdf/agreement_$token.pdf";
    $pdf->Output('F', $pdf_filename);

    // Insert tenancy agreement details into the database
    $insert_query = "
        INSERT INTO tenancy_agreements (property_id, user_id, agent_id, landlord_fullname, landlord_ic, landlord_address, 
            tenant_fullname, tenant_ic, tenant_address, property_address, monthly_rental, deposit, rental_start_date, 
            rental_end_date, contract_period, agreement_pdf, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')
    ";

    $stmt_insert = $conn->prepare($insert_query);
    $stmt_insert->bind_param('iiisssssssssssss', $property_id, $user_id, $agent_id, $landlord_fullname, $landlord_ic, $landlord_address,
        $tenant_fullname, $tenant_ic, $tenant_address, $property_address, $monthly_rental, $deposit, 
        $rental_start_date, $rental_end_date, $contract_period, $pdf_filename);
    
    $stmt_insert->execute();

    // Redirect back to conversation page
    header("Location: agent_message_user.php?token=$token&agreement=created");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Tenancy Agreement</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>Create Tenancy Agreement</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="landlord_fullname" class="form-label">Landlord Fullname</label>
                <input type="text" name="landlord_fullname" id="landlord_fullname" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="landlord_ic" class="form-label">Landlord IC</label>
                <input type="text" name="landlord_ic" id="landlord_ic" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="landlord_address" class="form-label">Landlord Address</label>
                <input type="text" name="landlord_address" id="landlord_address" class="form-control" required>
            </div>
             <div class="mb-3">
                <label for="tenant_fullname" class="form-label">Tenant Fullname</label>
                <input type="text" name="tenant_fullname" id="tenant_fullname" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="tenant_ic" class="form-label">Tenant IC</label>
                <input type="text" name="tenant_ic" id="tenant_ic" class="form-control" required>
            </div>
           <div class="mb-3">
    <label for="tenant_address" class="form-label">Tenant Address</label>
    <input type="text" name="tenant_address" id="tenant_address" class="form-control" required>
</div>
            <div class="mb-3">
                <label for="property_address" class="form-label">Property Address</label>
                <input type="text" name="property_address" id="property_address" class="form-control" required>
            </div>
            
            <div class="mb-3">
                <label for="monthly_rental" class="form-label">Monthly Rental (RM)</label>
                <input type="number" name="monthly_rental" id="monthly_rental" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="deposit" class="form-label">Deposit (RM)</label>
                <input type="number" name="deposit" id="deposit" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="rental_start_date" class="form-label">Rental Start Date</label>
                <input type="date" name="rental_start_date" id="rental_start_date" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="rental_end_date" class="form-label">Rental End Date</label>
                <input type="date" name="rental_end_date" id="rental_end_date" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="contract_period" class="form-label">Contract Period (e.g., one year)</label>
                <input type="text" name="contract_period" id="contract_period" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Create Agreement</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


