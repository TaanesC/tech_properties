<?php
session_start();
include 'config.php';

if (!isset($_SESSION['banker_id'])) {
    header("Location: banker_login.php");
    exit();
}

if (!isset($_GET['submission_id'])) {
    die("Submission ID is missing.");
}

$submission_id = $_GET['submission_id'];

$query = "
    SELECT 
        ls.submission_id, 
        u.user_fullname, 
        ls.loan_amount,
        ls.id_proof,
        ls.epf_statements, 
        ls.bank_statements, 
        ls.payslips, 
        p.title, 
        p.location, 
        p.type, 
        p.price, 
        ls.created_at 
    FROM 
        loan_submissions ls 
    JOIN 
        users u ON ls.user_id = u.user_id
    JOIN 
        properties p ON ls.property_id = p.property_id
    WHERE 
        ls.submission_id = ?
";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $submission_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("No loan submission found with the given ID.");
}

$submission_details = $result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Submission Details</title>
    
       <style>
    .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        
        </style>
    
</head>
<body>
    
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="banker_dashboard.php">TECH PROPERTIES</a>
    </nav>
    
    <div>rrr</div>

    
<div class="container mt-5">
    <h2>Loan Submission Details</h2>
    <p>User Full Name: <?php echo htmlspecialchars($submission_details['user_fullname']); ?></p>
    <p>Title: <?php echo htmlspecialchars($submission_details['title']); ?></p>
    <p>Location: <?php echo htmlspecialchars($submission_details['location']); ?></p>
    <p>Type: <?php echo htmlspecialchars($submission_details['type']); ?></p>
    <p>Price: <?php echo htmlspecialchars($submission_details['price']); ?></p>
    <p>Created At: <?php echo htmlspecialchars($submission_details['created_at']); ?></p>
</div>
    
    <div class="card-body">
            <p><strong>User Full Name:</strong> <?php echo htmlspecialchars($submission_details['user_fullname']); ?></p>
            <table class="table">
                <tbody>
                    <tr>
                        <th>Loan Amount</th>
                        <td><?php echo htmlspecialchars($submission_details['loan_amount']); ?></td>
                    </tr>
                    <tr>
                        <th>ID Proof</th>
                        <td><a href="<?php echo htmlspecialchars($submission_details['id_proof']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>EPF Statements</th>
                        <td><a href="<?php echo htmlspecialchars($$submission_details['epf_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Bank Statements</th>
                        <td><a href="<?php echo htmlspecialchars($submission_details['bank_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Payslips</th>
                        <td><a href="<?php echo htmlspecialchars($submission_details['payslips']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    
                </tbody>
            </table>
        </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


