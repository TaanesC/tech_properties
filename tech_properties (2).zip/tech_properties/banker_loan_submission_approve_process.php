<?php
session_start();
include 'config.php';

if (!isset($_SESSION['banker_id'])) {
    header("Location: banker_login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['submission_id']) && isset($_POST['lawyer_id'])) {
        $submission_id = intval($_POST['submission_id']);
        $lawyer_id = intval($_POST['lawyer_id']); 
        $banker_id = $_SESSION['banker_id'];

        $updateQuery = "UPDATE loan_submissions SET status = 'Approved', lawyer_id = ? WHERE submission_id = ?";
        $stmt = $conn->prepare($updateQuery);

        if ($stmt) {
            $stmt->bind_param("ii", $lawyer_id, $submission_id);
            
            if ($stmt->execute()) {
                notifyUserAndAgent($submission_id, "Your loan submission has been approved and a lawyer has been assigned.");

                // Redirect to banker_loan_submission.php
                header("Location: banker_loan_submission.php?status=approved");
                exit();
            } else {
                die("Error executing update: " . $stmt->error);
            }
            $stmt->close();
        } else {
            die("Error preparing statement: " . $conn->error);
        }
    } else {
        die("Submission ID or Lawyer ID is missing.");
    }
}

function notifyUserAndAgent($submission_id, $message) {
}

$conn->close();
?>

