<?php
session_start();
require 'config.php';

// Fetch filters from form submission if available
$location = isset($_GET['location']) ? $_GET['location'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$rent_or_sale = isset($_GET['rent_or_sale']) ? $_GET['rent_or_sale'] : '';
$sort_price = isset($_GET['sort_price']) ? $_GET['sort_price'] : '';
$min_price = isset($_GET['min_price']) ? $_GET['min_price'] : '';
$max_price = isset($_GET['max_price']) ? $_GET['max_price'] : '';

// Base query
$sql = "SELECT * FROM properties WHERE status = 'approved' AND rented_or_sold = 'available'";

// Apply filters to the query
if ($location) {
    $sql .= " AND location = '$location'";
}
if ($type) {
    $sql .= " AND type = '$type'";
}
if ($rent_or_sale) {
    $sql .= " AND rent_or_sale = '$rent_or_sale'";
}
if ($min_price && $max_price) {
    $sql .= " AND price BETWEEN $min_price AND $max_price";
}

// Apply sorting
if ($sort_price === 'low_to_high') {
    $sql .= " ORDER BY price ASC";
} elseif ($sort_price === 'high_to_low') {
    $sql .= " ORDER BY price DESC";
}

// Execute query
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Listings - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://kit.fontawesome.com/a076d05399.css" rel="stylesheet">
    <style>
        /* Navbar */
        .navbar {
            background-color: #001f3f;
            padding: 15px 20px;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 24px;
        }

        /* Banner */
        .banner {
            background-image: url('—Pngtree—high-end atmosphere black gold real_936051.jpg');
            background-size: cover;
            background-position: center;
            height: 500px;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
        }
        .banner h1 {
            font-size: 48px;
            font-weight: bold;
        }

        /* Main Content */
        body {
            background-color: #f5f5f5;
            margin-top: 80px;
        }
        
        h2 {
            font-weight: bold;
            color: #333;
        }
        
        /* Property Container */
        .property-container {
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            transition: transform 0.3s;
        }
        .property-container:hover {
            transform: scale(1.02);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
        }
        
        /* Image Carousel */
        .property-image img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        /* Property Details */
        .property-details {
            padding: 20px;
        }
        .property-title {
            font-size: 1.25rem;
            font-weight: bold;
            color: #007bff;
        }
        .property-price {
            color: #28a745;
            font-weight: bold;
            margin: 10px 0;
        }
        .details-icons {
            display: flex;
            justify-content: space-around;
            color: #555;
        }
        .details-icons i {
            margin-right: 5px;
            color: #007bff;
        }

        /* Footer */
        .footer {
            background-color: #001f3f;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
    </style>
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <a class="navbar-brand" href="#">TECH PROPERTIES</a>
    <div class="ms-auto">
        <a href="user_dashboard.php" class="btn btn-outline-light">
            <i class="fas fa-user-circle"></i> Dashboard
        </a>
    </div>
</nav>

<!-- Banner -->
<div class="banner">
    <h1>Find Your Dream Property</h1>
    <p>Explore the best properties for rent or sale</p>
</div>

<!-- Main Container -->
<div class="container mt-5">
    <h2 class="text-center mb-4">Available Property Listings</h2>

    <!-- Filters Form -->
    <form method="GET" class="row g-3 mb-4">
        <div class="col-md-3">
            <input type="text" name="location" class="form-control" placeholder="Location">
        </div>
        <div class="col-md-3">
            <select name="type" class="form-select">
                <option value="">Type</option>
                <option value="house">House</option>
                <option value="apartment">Apartment</option>
                                <option value="condominuim">Condominium</option>
                                                                <option value="flat">Flat</option>


            </select>
        </div>
        <div class="col-md-2">
            <select name="rent_or_sale" class="form-select">
                <option value="">For Rent/Sale</option>
                <option value="for_rent">For Rent</option>
                <option value="for_sale">For Sale</option>
            </select>
        </div>
        <div class="col-md-2">
            <input type="number" name="min_price" class="form-control" placeholder="Min Price">
        </div>
        <div class="col-md-2">
            <input type="number" name="max_price" class="form-control" placeholder="Max Price">
        </div>
        <div class="col-md-2 filter-btn">
            <button type="submit" class="btn btn-primary">Apply Filters</button>
        </div>
    </form>

    <!-- Properties Listing -->
    <div class="row">
        <?php while ($property = $result->fetch_assoc()) { ?>
            <div class="col-md-4 mb-4">
                <div class="property-container">
                    <!-- Image carousel -->
                    <div id="carousel<?php echo $property['property_id']; ?>" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="<?php echo htmlspecialchars($property['cover_pic']); ?>" class="d-block property-image" alt="Cover Image">
                            </div>
                            <?php for ($i = 1; $i <= 5; $i++) {
                                $additional_pic = 'additional_pic_' . $i;
                                if (!empty($property[$additional_pic])) { ?>
                                    <div class="carousel-item">
                                        <img src="<?php echo htmlspecialchars($property[$additional_pic]); ?>" class="d-block property-image" alt="Additional Image <?php echo $i; ?>">
                                    </div>
                                <?php }
                            } ?>
                        </div>
                        <a class="carousel-control-prev" href="#carousel<?php echo $property['property_id']; ?>" role="button" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        </a>
                        <a class="carousel-control-next" href="#carousel<?php echo $property['property_id']; ?>" role="button" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        </a>
                    </div>

                    <!-- Property Details -->
                    <div class="property-details">
                        <h5 class="property-title"><?php echo htmlspecialchars($property['title']); ?></h5>
                        <p class="property-price">RM <?php echo number_format($property['price']); ?></p>
                        <p><i class="fas fa-map-marker-alt"></i> <?php echo htmlspecialchars($property['location']); ?></p>
                        <p><i class="fas fa-home"></i> <?php echo htmlspecialchars($property['type']); ?> - <?php echo htmlspecialchars($property['rent_or_sale']); ?></p>
                        <div class="details-icons">
                            <span><i class="fas fa-ruler-combined"></i> <?php echo htmlspecialchars($property['sqft']); ?> sqft</span>
                            <span><i class="fas fa-bed"></i> <?php echo htmlspecialchars($property['bedrooms']); ?> Bedrooms</span>
                            <span><i class="fas fa-bath"></i> <?php echo htmlspecialchars($property['bathrooms']); ?> Bathrooms</span>
                        </div>
                    </div>
                    
                    <a href="property_details.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-primary">View Full Details</a>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<!-- Footer -->
<div class="footer">
    <p>&copy; 2024 TECH PROPERTIES. All Rights Reserved.</p>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>




