<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit();
}


if (isset($_GET['property_id'])) {
    $property_id = $_GET['property_id'];

    // Fetch property details from the database
    $sql = "SELECT p.*, a.agent_fullname, a.ren_number, a.profile_pic AS agent_profile_pic 
            FROM properties p
            JOIN agents a ON p.agent_id = a.agent_id
            WHERE p.property_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $property_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $property = $result->fetch_assoc();
    } else {
        echo "Property not found.";
        exit;
    }
} else {
    echo "Invalid property ID.";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Details</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
       .navbar {
            background-color: #001f3f;
            padding: 15px 20px;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 24px;
        }

        /* General styling */
        .container {
            margin-top: 90px;
            padding: 20px;
            max-width: 900px;
        }
        .property-image img {
            height:  850px;
            width:  850px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
        .carousel-control-prev-icon, .carousel-control-next-icon {
            background-color: #1d3557;
        }
        .property-details h5, .property-details p {
            color: #1d3557;
        }
        .details-icons p {
            display: inline-block;
            margin-right: 15px;
            font-size: 16px;
            color: #1d3557;
        }
        .details-icons i {
            color: #457b9d;
            margin-right: 6px;
        }

        /* Agent details */
        .agent-details {
            padding: 15px;
            background: #f1faee;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }
        .agent-details h6 {
            color: #1d3557;
            margin-bottom: 0;
        }
        .agent-details img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
        }

        /* Buttons */
        .btn-secondary, .btn-info, .btn-success {
            color: white;
            margin-top: 8px;
            font-weight: bold;
        }
        .btn-secondary {
            background-color: #457b9d;
        }
        .btn-secondary:hover {
            background-color: #1d3557;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="property_listings.php">TECH PROPERTIES</a>
        <div class="ms-auto">
        <a href="user_dashboard.php" class="btn btn-outline-light">
            <i class="fas fa-user-circle"></i> Dashboard
        </a>
    </div>
    
</nav>

<div class="container mt-5">
    <h2 class="text-center"><?php echo htmlspecialchars($property['title']); ?></h2>

    <div id="carouselProperty" class="carousel slide mt-4" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <div class="property-image">
                    <img src="<?php echo htmlspecialchars($property['cover_pic']); ?>" alt="Cover Image">
                </div>
            </div>
            <?php for ($i = 1; $i <= 5; $i++) {
                $additional_pic = 'additional_pic_' . $i;
                if (!empty($property[$additional_pic])) { ?>
                    <div class="carousel-item">
                        <div class="property-image">
                            <img src="<?php echo htmlspecialchars($property[$additional_pic]); ?>" alt="Additional Image <?php echo $i; ?>">
                        </div>
                    </div>
                <?php }
            } ?>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselProperty" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselProperty" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
        </button>
    </div>

    <div class="property-details mt-4">
        <h5>Price: RM <?php echo number_format($property['price']); ?></h5>
        <p>Location: <?php echo htmlspecialchars($property['location']); ?></p>
        <p>Type: <?php echo htmlspecialchars($property['type']); ?></p>
        <p>For: <?php echo htmlspecialchars($property['rent_or_sale']); ?></p>
        <div class="details-icons mt-3">
            <p><i class="fas fa-ruler-combined"></i><?php echo htmlspecialchars($property['sqft']); ?> sqft</p>
            <p><i class="fas fa-bed"></i><?php echo htmlspecialchars($property['bedrooms']); ?> Bedrooms</p>
            <p><i class="fas fa-bath"></i><?php echo htmlspecialchars($property['bathrooms']); ?> Bathrooms</p>
        </div>
        <p><strong>Description:</strong> <?php echo nl2br(htmlspecialchars($property['description'])); ?></p>
    </div>

    <div class="agent-details mt-4 d-flex align-items-center">
        <img src="<?php echo htmlspecialchars($property['agent_profile_pic']); ?>" alt="Agent Profile Picture" class="me-3">
        <div>
            <h6><?php echo htmlspecialchars($property['agent_fullname']); ?></h6>
            <p>REN Number: <?php echo htmlspecialchars($property['ren_number']); ?></p>
            <a href="user_message_agent.php?property_id=<?php echo htmlspecialchars($property['property_id']); ?>" class="btn btn-secondary">Message</a>
            <a href="user_fix_appointment_agent.php?property_id=<?php echo htmlspecialchars($property['property_id']); ?>" class="btn btn-secondary">Fix Appointment</a>
        </div>
    </div>

    <?php if ($property['rent_or_sale'] == 'for_sale') { ?>
        <div class="mt-4">
            <a href="user_check_loan_eligible_agent.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-info">Check Loan Eligibility</a>
            <a href="user_submit_loan_application_agent.php?property_id=<?php echo $property['property_id']; ?>" class="btn btn-success">Submit Loan Application</a>
        </div>
    <?php } ?>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</body>
</html>




