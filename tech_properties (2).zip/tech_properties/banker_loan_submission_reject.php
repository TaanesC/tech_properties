<?php
session_start();
include 'config.php';

if (!isset($_GET['submission_id'])) {
    die("No submission ID provided.");
}

$submission_id = $_GET['submission_id'];

$query = "UPDATE loan_submissions SET status = 'rejected' WHERE submission_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $submission_id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    header("Location: banker_loan_submission.php?status=rejected");
    exit();
} else {
    echo "Failed to reject the submission.";
}

$stmt->close();
$conn->close();
?>








