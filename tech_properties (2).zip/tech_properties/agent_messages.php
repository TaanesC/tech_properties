<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];

$filter = isset($_GET['filter']) ? $_GET['filter'] : 'user';

$filter_query = "";
if ($filter === 'user') {
    $filter_query = "AND sender = 'user'";
} elseif ($filter === 'banker') {
    $filter_query = "AND sender = 'banker'";
} elseif ($filter === 'lawyer') {
    $filter_query = "AND sender = 'lawyer'";
}

$query = "
    SELECT m.message_id, m.token, m.sender, m.receiver, m.message_text, m.created_at, p.title AS property_title, 
           p.rent_or_sale, u.user_fullname
    FROM messages m
    LEFT JOIN users u ON m.user_id = u.user_id
    LEFT JOIN properties p ON m.property_id = p.property_id
    WHERE m.agent_id = ? $filter_query
    ORDER BY m.created_at DESC
";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    die('MySQL prepare error: ' . $conn->error);
}

$stmt->bind_param('i', $agent_id);
$stmt->execute();

$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agent Messages</title>
    <!-- Add Bootstrap and custom styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1 class="mt-4">Agent Messages</h1>

        <div class="btn-group mb-3">
            <a href="agent_messages.php?filter=user" class="btn btn-primary">User</a>
            <a href="agent_messages.php?filter=banker" class="btn btn-secondary">Banker</a>
            <a href="agent_messages.php?filter=lawyer" class="btn btn-warning">Lawyer</a>
        </div>

        <div class="list-group">
            <?php
            $tokens = [];  
            while ($row = $result->fetch_assoc()) {
                if (in_array($row['token'], $tokens)) {
                    continue;
                }
                $tokens[] = $row['token'];  

                ?>
                <a href="agent_message_<?php echo strtolower($row['sender']); ?>.php?token=<?php echo $row['token']; ?>" class="list-group-item list-group-item-action">
                    <div class="d-flex w-100 justify-content-between">

                        <h5 class="mb-1"><?php echo htmlspecialchars($row['property_title']); ?></h5>

                        <p class="mb-1"><?php echo htmlspecialchars($row['message_text']); ?></p>
                    </div>
                    <small>Received: <?php echo date('Y-m-d H:i:s', strtotime($row['created_at'])); ?> | Property Type: <?php echo htmlspecialchars($row['rent_or_sale']); ?></small>
                </a>
            <?php } ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>










