<?php
session_start();
require 'config.php';

if (!isset($_SESSION['lawyer_id'])) {
    header('Location: lawyer_login.php');
    exit();
}

$lawyer_id = $_SESSION['lawyer_id'];

$query = "SELECT a.appointment_id, a.user_id, a.appointment_date, a.appointment_status,
          u.user_fullname, p.title, p.location, p.type, p.price, a.created_at
          FROM appointments AS a
          LEFT JOIN users AS u ON a.user_id = u.user_id
          LEFT JOIN properties AS p ON a.property_id = p.property_id
          WHERE a.lawyer_id = ? ORDER BY a.created_at DESC";

$stmt = $conn->prepare($query);
$stmt->bind_param('i', $lawyer_id);
$stmt->execute();
$result = $stmt->get_result();
$appointments = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lawyer Appointments | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
 <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="lawyer_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
        <div>rrr</div>
    <div class="container mt-5">
        <h2>Your Appointments</h2>
        <table class="table">
            <thead>
                <tr>
                    <th>User Name</th>
                    <th>Property Title</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>Price</th>
                    <th>Created At</th>
                    <th>Appointment Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?= htmlspecialchars($appointment['user_fullname']) ?></td>
                        <td><?= htmlspecialchars($appointment['title']) ?></td>
                        <td><?= htmlspecialchars($appointment['location']) ?></td>
                        <td><?= htmlspecialchars($appointment['type']) ?></td>
                        <td><?= htmlspecialchars($appointment['price']) ?></td>
                        <td><?= htmlspecialchars($appointment['created_at']) ?></td>
                        <td><?= htmlspecialchars($appointment['appointment_date']) ?></td>
                        <td><?= htmlspecialchars($appointment['appointment_status']) ?></td>
                        <td>
                            <a href="lawyer_appointment_confirm.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-success">Confirm</a>
                            <a href="lawyer_appointment_schedule_cancel.php?appointment_id=<?= $appointment['appointment_id'] ?>" class="btn btn-danger">Cancel</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>


