<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id']) || $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$agreement_id = $_POST['agreement_id'];
$signed_agreement = $_FILES['signed_agreement'];

$upload_dir = 'user_signed_agreement_pdf/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

if ($signed_agreement['error'] == 0 && in_array($signed_agreement['type'], ['application/pdf'])) {
    $file_path = $upload_dir . basename($signed_agreement['name']); // Keep the original filename
    if (move_uploaded_file($signed_agreement['tmp_name'], $file_path)) {
        
        $query = "
            UPDATE tenancy_agreements 
            SET user_signed_agreement_pdf = ? 
            WHERE agreement_id = ? AND user_id = ?
        ";
        $stmt = $conn->prepare($query);

        if ($stmt === false) {
            die("Error preparing query: " . $conn->error);
        }

        $stmt->bind_param('sii', $file_path, $agreement_id, $user_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            header('Location: user_tenancy_agreement.php?upload=success');
        } else {
            echo "Failed to update record. Please try again.";
        }

        $stmt->close();
    } else {
        echo "Failed to upload file.";
    }
} else {
    echo "Invalid file type. Please upload a PDF document.";
}
?>


