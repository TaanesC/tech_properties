<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

$searchQuery = '';
if (isset($_POST['search'])) {
    $search = "%{$_POST['search']}%";
    $searchQuery = "WHERE user_fullname LIKE ? OR user_id LIKE ? OR user_email LIKE ? OR user_phonenumber LIKE ?";
} else {
    $search = '';
}

$query = "SELECT user_id, user_email, user_fullname, user_phonenumber, user_age, user_occupation FROM users $searchQuery";
$stmt = $conn->prepare($query);

if ($searchQuery) {
    $stmt->bind_param('ssss', $search, $search, $search, $search);
}

$stmt->execute();
$result = $stmt->get_result();
$users = $result->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
 <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
        <div>rrr</div>
    <div class="container mt-5">
        <h2>Manage Users</h2>
        <form method="post" class="my-3">
            <input type="text" name="search" class="form-control" placeholder="Search by Fullname, ID, Email, or Phone Number">
            <button type="submit" class="btn btn-primary mt-2">Search</button>
        </form>
        
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>User ID</th>
                    <th>Email</th>
                    <th>Full Name</th>
                    <th>Phone Number</th>
                    <th>Age</th>
                    <th>Occupation</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?= htmlspecialchars($user['user_id']) ?></td>
                        <td><?= htmlspecialchars($user['user_email']) ?></td>
                        <td><?= htmlspecialchars($user['user_fullname']) ?></td>
                        <td><?= htmlspecialchars($user['user_phonenumber']) ?></td>
                        <td><?= htmlspecialchars($user['user_age']) ?></td>
                        <td><?= htmlspecialchars($user['user_occupation']) ?></td>
                        <td>
                            <a href="admin_specific_user_analytics.php?user_id=<?= $user['user_id'] ?>" class="btn btn-info">Analytics</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

