<?php
session_start();
include 'config.php';


if (!isset($_GET['eligibility_id'])) {
    die("Eligibility ID not provided.");
}

$id = $_GET['eligibility_id'];

// Prepare the update query
$query = "UPDATE loan_eligibility SET eligibility_status = 'approved' WHERE eligibility_id = ?"; // Change 'eligibility_id' to 'id' if that's the actual column name
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("MySQL prepare error: " . htmlspecialchars($conn->error));
}

$stmt->bind_param("i", $id);

$stmt->execute();

if ($stmt->affected_rows > 0) {
    header("Location: agent_loan_eligibility.php");
    exit();
} else {
    if ($stmt->errno) {
        echo "Failed to update status. Error: " . htmlspecialchars($stmt->error);
    } else {
        echo "No changes made. The eligibility ID may not exist or the status was already approved.";
    }
}

$stmt->close();

$conn->close();
?>



