<?php
require_once 'fpdf.php'; // Include FPDF library

function generatePDF($conn, $agreement_id) {
    // Fetch agreement data from the database
    $stmt = $conn->prepare("SELECT * FROM tenancy_agreements WHERE id = ?");
    $stmt->bind_param("i", $agreement_id);
    $stmt->execute();
    $agreement = $stmt->get_result()->fetch_assoc();

    // Initialize PDF
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);

    // Title
    $pdf->Cell(0, 10, 'Contract of Tenancy Agreement', 0, 1, 'C');
    $pdf->Ln(10);

    // Agreement content
    $pdf->SetFont('Arial', '', 12);
    $pdf->MultiCell(0, 10, "Property Address: " . $agreement['property_address']);
    $pdf->MultiCell(0, 10, "Date: " . date('d M Y'));

    $pdf->Ln(5);
    $pdf->MultiCell(0, 10, "In consideration of the agreements of the Resident(s), known as:");
    $pdf->MultiCell(0, 10, "Tenant: " . $agreement['tenant_ic']);
    $pdf->MultiCell(0, 10, "Address: " . $agreement['tenant_address']);

    $pdf->Ln(5);
    $pdf->MultiCell(0, 10, "Owner:");
    $pdf->MultiCell(0, 10, "Landlord: " . $agreement['landlord_ic']);
    $pdf->MultiCell(0, 10, "Address: " . $agreement['landlord_address']);

    // Agreement period and terms
    $pdf->Ln(10);
    $pdf->MultiCell(0, 10, "For the period commencing on " . $agreement['rental_start_date'] . " until " . $agreement['rental_end_date'] . " (" . $agreement['contract_period'] . ").");
    $pdf->MultiCell(0, 10, "Monthly Rental Rate: RM " . $agreement['monthly_rental']);
    $pdf->MultiCell(0, 10, "Rental Deposit: RM " . $agreement['deposit']);

    // Signatures
    $pdf->Ln(10);
    $pdf->Cell(0, 10, "Tenant's Signature: _______________________", 0, 1);
    $pdf->Cell(0, 10, "Landlord's Signature: _______________________", 0, 1);

    // Save PDF
    $pdf_filename = 'agreements/agreement_' . $agreement_id . '.pdf';
    $pdf->Output('F', $pdf_filename);

    // Update the agreement record with the PDF path
    $update_stmt = $conn->prepare("UPDATE tenancy_agreements SET agreement_pdf = ? WHERE id = ?");
    $update_stmt->bind_param("si", $pdf_filename, $agreement_id);
    $update_stmt->execute();
}
?>
