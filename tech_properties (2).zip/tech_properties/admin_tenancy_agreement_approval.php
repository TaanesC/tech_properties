<?php
// Include database connection
include 'config.php';

// Check if the admin is logged in
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit;
}

// Fetch tenancy agreements with 'pending' status
$query = "
    SELECT ta.agreement_id, p.title, ta.property_address, ta.monthly_rental, ta.deposit, 
           ta.rental_start_date, ta.rental_end_date, ta.contract_period, ta.status,
           ta.agreement_pdf, ta.user_signed_agreement_pdf, ta.landlord_signed_agreement_pdf
    FROM tenancy_agreements ta
    JOIN properties p ON ta.property_id = p.property_id
    WHERE ta.status = 'pending'";

$result = $conn->query($query);

// Fetch lawyers to populate the dropdown
$lawyer_query = "SELECT lawyer_id, lawyer_fullname FROM lawyers";
$lawyer_result = $conn->query($lawyer_query);

// Handle approve or reject actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $agreement_id = $_POST['agreement_id'];
    $action = $_POST['action']; // 'approve' or 'reject'

    if ($action === 'approve' && isset($_POST['lawyer_id'])) {
        $lawyer_id = $_POST['lawyer_id'];
        $new_status = 'submitted';

        // Update the status and lawyer_id in the database
        $update_query = "UPDATE tenancy_agreements SET status = ?, lawyer_id = ? WHERE agreement_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param('sii', $new_status, $lawyer_id, $agreement_id);

        if ($stmt->execute()) {
            header('Location: admin_tenancy_agreement_approval.php?update=success');
            exit;
        } else {
            echo "Error updating status: " . $stmt->error;
        }
    } elseif ($action === 'reject') {
        $new_status = 'rejected';

        // Update the status in the database
        $update_query = "UPDATE tenancy_agreements SET status = ? WHERE agreement_id = ?";
        $stmt = $conn->prepare($update_query);
        $stmt->bind_param('si', $new_status, $agreement_id);

        if ($stmt->execute()) {
            header('Location: admin_tenancy_agreement_approval.php?update=success');
            exit;
        } else {
            echo "Error updating status: " . $stmt->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Tenancy Agreement Approval</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container">
    <h2>Tenancy Agreement Approval</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Property Title</th>
                <th>Property Address</th>
                <th>Monthly Rental</th>
                <th>Deposit</th>
                <th>Rental Start Date</th>
                <th>Rental End Date</th>
                <th>Contract Period</th>
                <th>Status</th>
                <th>Agreement PDF</th>
                <th>User Signed Agreement</th>
                <th>Landlord Signed Agreement</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['property_address']); ?></td>
                    <td><?php echo htmlspecialchars($row['monthly_rental']); ?></td>
                    <td><?php echo htmlspecialchars($row['deposit']); ?></td>
                    <td><?php echo htmlspecialchars($row['rental_start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['rental_end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['contract_period']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td><a href="<?php echo htmlspecialchars($row['agreement_pdf']); ?>" target="_blank">View Agreement</a></td>
                    <td><a href="<?php echo htmlspecialchars($row['user_signed_agreement_pdf']); ?>" target="_blank">View User Signed Agreement</a></td>
                    <td><a href="<?php echo htmlspecialchars($row['landlord_signed_agreement_pdf']); ?>" target="_blank">View Landlord Signed Agreement</a></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="agreement_id" value="<?php echo $row['agreement_id']; ?>">
                            <select name="lawyer_id" class="form-control mb-2" required>
                                <option value="">Select Lawyer</option>
                                <?php while ($lawyer = $lawyer_result->fetch_assoc()): ?>
                                    <option value="<?php echo $lawyer['lawyer_id']; ?>">
                                        <?php echo htmlspecialchars($lawyer['lawyer_fullname']); ?>
                                    </option>
                                <?php endwhile; ?>
                            </select>
                            <button type="submit" name="action" value="approve" class="btn btn-success">Approve</button>
                            <button type="submit" name="action" value="reject" class="btn btn-danger">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>
