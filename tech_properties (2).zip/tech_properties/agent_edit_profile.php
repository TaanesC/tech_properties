<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];
$sql = "SELECT agent_email, agent_phonenumber, profile_pic FROM agents WHERE agent_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $agent_id);
$stmt->execute();
$stmt->bind_result($agent_email, $agent_phonenumber, $profile_pic);
$stmt->fetch();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $new_email = $_POST['agent_email'];
    $new_phonenumber = $_POST['agent_phonenumber'];
    
    if ($_FILES['profile_pic']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
        move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file);
        
        $sql = "UPDATE agents SET profile_pic = ? WHERE agent_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $target_file, $agent_id);
        $stmt->execute();
        $stmt->close();
    }
    
    $sql = "UPDATE agents SET agent_email = ?, agent_phonenumber = ? WHERE agent_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $new_email, $new_phonenumber, $agent_id);
    $stmt->execute();
    $stmt->close();
    
    header('Location: agent_dashboard.php'); // Redirect after update
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%; 
            padding: 20px;
            position: fixed; 
            top: 0;
            left: 0;
            z-index: 1000; 
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 70px; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Edit Profile</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="agent_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="agent_email" name="agent_email" value="<?php echo $agent_email; ?>" required>
            </div>
            <div class="mb-3">
                <label for="agent_phonenumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="agent_phonenumber" name="agent_phonenumber" value="<?php echo $agent_phonenumber; ?>" required>
            </div>
            <div class="mb-3">
                <label for="profile_pic" class="form-label">Profile Picture</label>
                <input type="file" class="form-control" id="profile_pic" name="profile_pic">
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>







