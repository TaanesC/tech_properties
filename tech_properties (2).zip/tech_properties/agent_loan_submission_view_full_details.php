<?php
session_start();
include 'config.php';

if (!isset($_GET['submission_id'])) {
    die("No submission ID provided.");
}

$submission_id = $_GET['submission_id'];

// Prepare and execute the query to get full submission details
$query = "SELECT ls.*, u.user_fullname, ls.id_proof, ls.epf_statements, ls.bank_statements, ls.payslips, p.title, p.location, p.type, p.price 
          FROM loan_submissions ls
          JOIN users u ON ls.user_id = u.user_id
          JOIN properties p ON ls.property_id = p.property_id
          WHERE ls.submission_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $submission_id);
$stmt->execute();
$result = $stmt->get_result();
$submission = $result->fetch_assoc();

if (!$submission) {
    die("No submission found.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Submission Details</title>
    <style>
        body {
            background-color: #f8f9fa;
        }
        .card {
            margin: 20px 0;
        }
        .card-header {
            background-color: #007bff;
            color: white;
        }
        .table th {
            background-color: #007bff;
            color: white;
        }
 
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rr</div>
        <div>rr</div>
<div class="container mt-5">
    <div class="card">
        <div class="card-header">
            <h4>Loan Submission Details</h4>
        </div>
        <div class="card-body">
            <p><strong>User Full Name:</strong> <?php echo htmlspecialchars($submission['user_fullname']); ?></p>
            <table class="table">
                <tbody>
                    <tr>
                        <th>Loan Amount</th>
                        <td><?php echo htmlspecialchars($submission['loan_amount']); ?></td>
                    </tr>
                    <tr>
                        <th>ID Proof</th>
                        <td><a href="<?php echo htmlspecialchars($submission['id_proof']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>EPF Statements</th>
                        <td><a href="<?php echo htmlspecialchars($submission['epf_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Bank Statements</th>
                        <td><a href="<?php echo htmlspecialchars($submission['bank_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Payslips</th>
                        <td><a href="<?php echo htmlspecialchars($submission['payslips']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Created At</th>
                        <td><?php echo htmlspecialchars($submission['created_at']); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
    <a href="agent_loan_submission.php" class="btn btn-secondary">Back to Submissions</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


