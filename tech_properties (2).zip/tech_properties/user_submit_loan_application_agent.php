<?php
session_start();
include 'config.php';

$user_id = $_SESSION['user_id'];
$agent_id = $_SESSION['agent_id'];





if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $loan_amount = $_POST['loan_amount'];
    
    $upload_dir = 'uploads/';

    // Handle file uploads
    $id_proof = $upload_dir . basename($_FILES['id_proof']['name']);
    $epf_statements = $upload_dir . basename($_FILES['epf_statements']['name']);
    $bank_statements = $upload_dir . basename($_FILES['bank_statements']['name']);
    $payslips = $upload_dir . basename($_FILES['payslips']['name']);

    if (move_uploaded_file($_FILES['id_proof']['tmp_name'], $id_proof) &&
        move_uploaded_file($_FILES['epf_statements']['tmp_name'], $epf_statements) &&
        move_uploaded_file($_FILES['bank_statements']['tmp_name'], $bank_statements) &&
        move_uploaded_file($_FILES['payslips']['tmp_name'], $payslips)) {

        // Prepare the SQL statement
        $query = "INSERT INTO loan_submissions (user_id, agent_id, banker_id, loan_amount, id_proof, epf_statements, bank_statements, payslips, status, created_at, property_id) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?)";
        
        $property_id = $_GET['property_id']; 
        $status = 'pending'; 

        $stmt = $conn->prepare($query);
        
        if ($stmt === false) {
            die('Prepare failed: ' . htmlspecialchars($conn->error));
        }

        $banker_id = null;
        $stmt->bind_param("iiissssssi", $user_id, $agent_id, $banker_id, $loan_amount, $id_proof, $epf_statements, $bank_statements, $payslips, $status, $property_id);
        
    if ($stmt->execute()) {
    echo "<script>
            alert('Loan application submitted successfully.');
          </script>";
} else {
    echo "Error executing query: " . htmlspecialchars($stmt->error);
}
        // Close the statement
        $stmt->close();
    } else {
        echo "Error uploading files.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>   .navbar {
            background-color: #001f3f;
            padding: 15px 20px;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 24px;
        }</style>
    
    <title>Submit Loan Application</title>
</head>
<body>
    
       <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="property_listings.php">TECH PROPERTIES</a>
       
    
</nav>
<div class="container mt-5">
    <h2>Submit Loan Application</h2>
    <form action="" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="loan_amount">Loan Amount:</label>
            <input type="number" class="form-control" id="loan_amount" name="loan_amount" required>
        </div>
        <div class="form-group">
            <label for="id_proof">ID Proof:</label>
            <input type="file" class="form-control" id="id_proof" name="id_proof" required>
        </div>
        <div class="form-group">
            <label for="epf_statements">EPF Statements:</label>
            <input type="file" class="form-control" id="epf_statements" name="epf_statements" required>
        </div>
        <div class="form-group">
            <label for="bank_statements">Bank Statements:</label>
            <input type="file" class="form-control" id="bank_statements" name="bank_statements" required>
        </div>
        <div class="form-group">
            <label for="payslips">Payslips:</label>
            <input type="file" class="form-control" id="payslips" name="payslips" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit Loan Application</button>
    </form>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$conn->close();
?>

