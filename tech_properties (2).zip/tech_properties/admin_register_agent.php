<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['admin_email'])) {
    header('Location: admin_login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $agent_email = $_POST['agent_email'];
    $agent_fullname = $_POST['agent_fullname'];
    $agent_phonenumber = $_POST['agent_phonenumber'];
    $ren_number = $_POST['ren_number'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO agents (agent_email, agent_fullname, agent_phonenumber, ren_number, agent_password) VALUES (?, ?, ?, ?, ?)";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sssss", $agent_email, $agent_fullname, $agent_phonenumber, $ren_number, $hashed_password);
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Agent registered successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error registering agent: " . $conn->error . "</div>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Agent - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%; 
            padding: 20px;
            position: fixed; 
            top: 0;
            left: 0;
            z-index: 1000; 
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px; 
        }
        .container {
            max-width: 600px; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Register Agent</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="agent_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="agent_email" name="agent_email" required>
            </div>
            <div class="mb-3">
                <label for="agent_fullname" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="agent_fullname" name="agent_fullname" required>
            </div>
            <div class="mb-3">
                <label for="agent_phonenumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="agent_phonenumber" name="agent_phonenumber" required>
            </div>
            <div class="mb-3">
                <label for="ren_number" class="form-label">REN Number</label>
                <input type="text" class="form-control" id="ren_number" name="ren_number" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Register Agent</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
