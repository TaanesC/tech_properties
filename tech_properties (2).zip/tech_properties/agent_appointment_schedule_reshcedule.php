<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];

if (isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $new_appointment_date = $_POST['appointment_date']; 

        // Update appointment status to 'rescheduled' and change appointment_date
        $query = "UPDATE appointments SET appointment_status = 'rescheduled', appointment_date = ? WHERE appointment_id = ? AND agent_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('sii', $new_appointment_date, $appointment_id, $agent_id);
        $stmt->execute();

      

        header('Location: agent_appointment_schedule.php?status=rescheduled'); 
        exit();
    }
} else {
    header('Location: agent_appointment_schedule.php?error=invalid'); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reschedule Appointment | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>
<style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rr</div>
        <div>rr</div>

    <div class="container mt-4">
        <h2>Reschedule Appointment</h2>
        <form method="post">
            <form action="" method="POST">
            <div class="mb-3">
                <label for="appointment_date" class="form-label">Select Appointment Date and Time</label>
                <input type="datetime-local" name="appointment_date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Fix Appointment</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    </div>

    <script>
        $(document).ready(function() {
            $('#calendar').fullCalendar({
                selectable: true,
                select: function(start, end) {
                    var date = start.format(); 
                    $('#appointment_date').val(date); 
                    $('#calendar').fullCalendar('unselect'); 
                }
            });
        });
    </script>
</body>
</html>


