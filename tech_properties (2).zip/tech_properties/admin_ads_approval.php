<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

$sql = "SELECT * FROM properties WHERE status = 'pending'";
$result = $conn->query($sql);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $property_id = $_POST['property_id'];
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $update_sql = "UPDATE properties SET status = 'approved' WHERE property_id = ?";
        $stmt = $conn->prepare($update_sql);
        $stmt->bind_param("s", $property_id);
        $stmt->execute();
        
    } elseif ($action === 'reject') {
        $delete_sql = "DELETE FROM properties WHERE property_id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("s", $property_id);
        $stmt->execute();
        
        $_SESSION['message'] = "Advertisement has been rejected.";
    }

    header("Location: admin_ads_approval.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Advertisement Approval - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 70px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Advertisement Approval</h1>
        
        <?php if ($result->num_rows > 0): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Price (RM)</th>
                        <th>Location</th>
                        <th>Type</th>
                        <th>Rent/Sale</th>
                        <th>Sqft</th>
                        <th>Bedrooms</th>
                        <th>Bathrooms</th>
                        <th>Cover Picture</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['description']); ?></td>
                            <td><?php echo htmlspecialchars($row['price']); ?></td>
                            <td><?php echo htmlspecialchars($row['location']); ?></td>
                            <td><?php echo htmlspecialchars($row['type']); ?></td>
                            <td><?php echo htmlspecialchars($row['rent_or_sale']); ?></td>
                            <td><?php echo htmlspecialchars($row['sqft']); ?></td>
                            <td><?php echo htmlspecialchars($row['bedrooms']); ?></td>
                            <td><?php echo htmlspecialchars($row['bathrooms']); ?></td>
                            <td><img src="uploads/<?php echo htmlspecialchars($row['cover_pic']); ?>" alt="Cover" width="100"></td>
                            <td>
                                <form method="POST">
                                    <input type="hidden" name="property_id" value="<?php echo $row['property_id']; ?>">
                                    <button type="submit" name="action" value="approve" class="btn btn-success btn-sm">Approve</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">Reject</button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No pending advertisements for approval.</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


