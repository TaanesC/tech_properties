<?php
session_start();
include 'config.php';

if (!isset($_GET['eligibility_id'])) {
    die("Eligibility ID not provided.");
}

$eligibility_id = $_GET['eligibility_id'];

$query = "SELECT le.*, p.title, p.location, p.type, p.price 
          FROM loan_eligibility le 
          JOIN properties p ON le.property_id = p.property_id 
          WHERE le.eligibility_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $eligibility_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("No details found for this eligibility ID.");
}

$row = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Eligibility Details</title>
    
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }

        
        
        
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="user_dashboard.php">TECH PROPERTIES</a>
    </nav>

    <div>bbbb</div>
    
    
<div class="container mt-5">
    <h2>Loan Eligibility Details</h2>
    <table class="table table-bordered">
        <tr>
            <th>Title</th>
            <td><?php echo htmlspecialchars($row['title']); ?></td>
        </tr>
        <tr>
            <th>Location</th>
            <td><?php echo htmlspecialchars($row['location']); ?></td>
        </tr>
        <tr>
            <th>Type</th>
            <td><?php echo htmlspecialchars($row['type']); ?></td>
        </tr>
        <tr>
            <th>Price</th>
            <td><?php echo htmlspecialchars($row['price']); ?></td>
        </tr>
        <tr>
            <th>Created Date</th>
            <td><?php echo htmlspecialchars($row['created_at']); ?></td>
        </tr>
        <tr>
            <th>Eligibility Status</th>
            <td><?php echo htmlspecialchars($row['eligibility_status']); ?></td>
        </tr>
        <tr>
            <th>ID Proof</th>
            <td><a href="<?php echo htmlspecialchars($row['id_proof']); ?>" target="_blank">View Document</a></td>
        </tr>
        <tr>
            <th>EPF Statements</th>
            <td><a href="<?php echo htmlspecialchars($row['epf_statements']); ?>" target="_blank">View Document</a></td>
        </tr>
        <tr>
            <th>Bank Statements</th>
            <td><a href="<?php echo htmlspecialchars($row['bank_statements']); ?>" target="_blank">View Document</a></td>
        </tr>
        <tr>
            <th>Payslips</th>
            <td><a href="<?php echo htmlspecialchars($row['payslips']); ?>" target="_blank">View Document</a></td>
        </tr>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


