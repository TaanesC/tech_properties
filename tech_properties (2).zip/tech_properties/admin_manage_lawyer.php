<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

$searchQuery = "";
if (isset($_POST['search'])) {
    $searchInput = $_POST['search_input'];
    $searchQuery = "WHERE lawyer_id LIKE '%$searchInput%' 
                    OR lawyer_email LIKE '%$searchInput%' 
                    OR lawyer_fullname LIKE '%$searchInput%' 
                    OR lawyer_phonenumber LIKE '%$searchInput%' 
                    OR firm_number LIKE '%$searchInput%'";
}

$query = "SELECT lawyer_id, lawyer_email, lawyer_fullname, lawyer_phonenumber, firm_number FROM lawyers $searchQuery";
$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Lawyers | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            padding: 20px;
            width: 100%;
            position: fixed;
            top: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px;
        }
    </style>
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
    </nav>

    <div class="container content">
        <h2 class="mt-4 mb-4">Manage Lawyers</h2>

        <form action="" method="POST" class="mb-3">
            <div class="input-group">
                <input type="text" name="search_input" class="form-control" placeholder="Search by ID, Email, Name, Phone, or Firm Number" required>
                <button class="btn btn-primary" name="search" type="submit">Search</button>
            </div>
        </form>

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Lawyer ID</th>
                    <th>Email</th>
                    <th>Full Name</th>
                    <th>Phone Number</th>
                    <th>Firm Number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($lawyer = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($lawyer['lawyer_id']); ?></td>
                            <td><?php echo htmlspecialchars($lawyer['lawyer_email']); ?></td>
                            <td><?php echo htmlspecialchars($lawyer['lawyer_fullname']); ?></td>
                            <td><?php echo htmlspecialchars($lawyer['lawyer_phonenumber']); ?></td>
                            <td><?php echo htmlspecialchars($lawyer['firm_number']); ?></td>
                            <td>
                                <a href="admin_delete_lawyer.php?lawyer_id=<?php echo urlencode($lawyer['lawyer_id']); ?>" 
                                   class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Are you sure you want to delete this lawyer?');">
                                   Delete
                                </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No lawyers found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>

