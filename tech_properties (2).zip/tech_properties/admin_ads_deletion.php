<?php
session_start();
require 'config.php'; // Ensure the correct path to your config file

// Check if the admin is logged in (optional)
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

// Handle the property archiving
if (isset($_POST['archive_property'])) {
    $property_id = $_POST['property_id'];

    // Retrieve property details to store in rented_sold_analytics
    $query = "SELECT * FROM properties WHERE property_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $property_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $property = $result->fetch_assoc();

        // Insert property details into rented_sold_analytics table
        $insertQuery = "INSERT INTO rented_sold_analytics (property_id, agent_id, status, property_type, location, created_at)
                        VALUES (?, ?, ?, ?, ?, NOW())";
        $insertStmt = $conn->prepare($insertQuery);
        $insertStmt->bind_param('iisss', $property['property_id'], $property['agent_id'], $property['rented_or_sold'], $property['type'], $property['location']);
        $insertStmt->execute();

        // Update the status of the property instead of deleting it
        $updateQuery = "UPDATE properties SET rented_or_sold = 'archived' WHERE property_id = ?";
        $updateStmt = $conn->prepare($updateQuery);
        $updateStmt->bind_param('i', $property_id);
        
        if ($updateStmt->execute()) {
            $success_message = "Property has been successfully archived.";
        } else {
            $error_message = "Failed to archive the property.";
        }
    } else {
        $error_message = "Property not found.";
    }
}

// Retrieve all sold/rented properties for display
$query = "SELECT property_id, title, price, location, rented_or_sold FROM properties WHERE rented_or_sold IN ('rented', 'sold')";
$stmt = $conn->prepare($query);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Ads Deletion | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; /* Navy blue background */
            padding: 20px;
            width: 100%;
            position: fixed; /* Fix to the top */
            top: 0;
            z-index: 1000; /* Ensure it is above other elements */
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px; 
        }
    </style>
</head>
<body>

    <!-- Navbar/Header -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
    </nav>

    <!-- Main content -->
    <div class="container content">
        <h2 class="mt-4 mb-4">Manage Ads Deletion</h2>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success"><?php echo $success_message; ?></div>
        <?php elseif (isset($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Property ID</th>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($property = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($property['property_id']); ?></td>
                            <td><?php echo htmlspecialchars($property['title']); ?></td>
                            <td><?php echo htmlspecialchars($property['price']); ?></td>
                            <td><?php echo htmlspecialchars($property['location']); ?></td>
                            <td><?php echo htmlspecialchars($property['rented_or_sold']); ?></td>
                            <td>
                                <form action="" method="POST" class="d-inline">
                                    <input type="hidden" name="property_id" value="<?php echo $property['property_id']; ?>">
                                    <button type="submit" name="archive_property" class="btn btn-warning btn-sm" 
                                            onclick="return confirm('Are you sure you want to archive this property?');">
                                        Archive
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No rented or sold properties found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</body>
</html>




