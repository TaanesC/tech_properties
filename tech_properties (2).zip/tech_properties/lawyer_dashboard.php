<?php
session_start();
if (!isset($_SESSION['lawyer_id'])) {
    header('Location: lawyer_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lawyer Dashboard | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            padding: 20px;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px;
            padding: 20px;
        }
        .card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s;
            text-align: center;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .dashboard-options {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
        }
        .btn-logout {
            background-color: #dc3545;
            color: white;
            border: none;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="#">TECH PROPERTIES</a>
        <div class="ms-auto">
            <a href="lawyer_edit_profile.php" class="btn btn-light me-2">Edit Profile</a>
            <a href="lawyer_logout.php" class="btn btn-logout">Logout</a>
        </div>
    </nav>

    <div class="content container">
        <h1 class="text-center mb-4">Lawyer Dashboard</h1>
        <div class="dashboard-options">
            <a href="lawyer_tenancy_agreement.php" class="card p-4 col-md-3 text-decoration-none text-dark">
                <h4>Tenancy Agreement</h4>
            </a>
            <a href="lawyer_appointment_sign_in.php" class="card p-4 col-md-3 text-decoration-none text-dark">
                <h4>Appointment Sign In</h4>
            </a>
            <a href="lawyer_appointment_schedule_user.php" class="card p-4 col-md-3 text-decoration-none text-dark">
                <h4>Appointment Schedule</h4>
            </a>
            <a href="lawyer_messages.php" class="card p-4 col-md-3 text-decoration-none text-dark">
                <h4>Messages</h4>
            </a>
            <div class="card p-4 col-md-3">
                <h4>Tech Properties</h4>
            </div>
        </div>
    </div>
</body>
</html>
