<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['admin_email'])) {
    header('Location: admin_login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $lawyer_email = $_POST['lawyer_email'];
    $lawyer_fullname = $_POST['lawyer_fullname'];
    $lawyer_phonenumber = $_POST['lawyer_phonenumber'];
    $firm_number = $_POST['firm_number'];
    $password = $_POST['password'];
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO lawyers (lawyer_email, lawyer_fullname, lawyer_phonenumber, firm_number, lawyer_password) VALUES (?, ?, ?, ?, ?)";
    
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sssss", $lawyer_email, $lawyer_fullname, $lawyer_phonenumber, $firm_number, $hashed_password);
        if ($stmt->execute()) {
            echo "<div class='alert alert-success'>Lawyer registered successfully!</div>";
        } else {
            echo "<div class='alert alert-danger'>Error registering lawyer: " . $conn->error . "</div>";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Lawyer - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%; 
            padding: 20px;
            position: fixed; 
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px; 
        }
        .container {
            max-width: 600px; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Register Lawyer</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="lawyer_email" class="form-label">Email</label>
                <input type="email" class="form-control" id="lawyer_email" name="lawyer_email" required>
            </div>
            <div class="mb-3">
                <label for="lawyer_fullname" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="lawyer_fullname" name="lawyer_fullname" required>
            </div>
            <div class="mb-3">
                <label for="lawyer_phonenumber" class="form-label">Phone Number</label>
                <input type="text" class="form-control" id="lawyer_phonenumber" name="lawyer_phonenumber" required>
            </div>
            <div class="mb-3">
                <label for="firm_number" class="form-label">Firm Number</label>
                <input type="text" class="form-control" id="firm_number" name="firm_number" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Register Lawyer</button>
        </form>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>



