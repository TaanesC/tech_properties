<?php
session_start();
include 'config.php';

if (!isset($_SESSION['banker_id'])) {
    header("Location: banker_login.php");
    exit();
}

if (isset($_GET['submission_id'])) {
    $submission_id = intval($_GET['submission_id']);
    
    $query = "
        SELECT 
            ls.*, 
            a.ren_number,
            u.user_fullname, 
            p.title, 
            p.location, 
            p.type, 
            p.price 
        FROM 
            loan_submissions ls 
        JOIN 
            users u ON ls.user_id = u.user_id
        JOIN 
            properties p ON ls.property_id = p.property_id
             JOIN    
        agents a ON ls.agent_id = a.agent_id
        WHERE 
            ls.submission_id = ?
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $submission_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $submission = $result->fetch_assoc();

    if (!$submission) {
        die("No submission found.");
    }
} else {
    die("Submission ID is missing.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Submission Details</title>
     <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>Loan Submission Details</h2>
        <table class="table">
            <tbody>
                 <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="banker_dashboard.php">TECH PROPERTIES</a>
    </nav>
                <tr>
                    <th>REN Number:</th>
                    <td><?php echo htmlspecialchars($submission['ren_number']); ?></td>
                </tr>
                <tr>
                    <th>User Full Name:</th>
                    <td><?php echo htmlspecialchars($submission['user_fullname']); ?></td>
                </tr>

                <tr>
                    <th>Title:</th>
                    <td><?php echo htmlspecialchars($submission['title']); ?></td>
                </tr>
                <tr>
                    <th>Location:</th>
                    <td><?php echo htmlspecialchars($submission['location']); ?></td>
                </tr>
                <tr>
                    <th>Type:</th>
                    <td><?php echo htmlspecialchars($submission['type']); ?></td>
                </tr>
                <tr>
                    <th>Price:</th>
                    <td><?php echo htmlspecialchars($submission['price']); ?></td>
                </tr>
                <tr>
                    <th>Created At:</th>
                    <td><?php echo htmlspecialchars($submission['created_at']); ?></td>
                </tr>
                <tr>
                    <th>Status:</th>
                    <td><?php echo htmlspecialchars($submission['status']); ?></td>
                </tr>
                 <th>ID Proof</th>
                        <td><a href="<?php echo htmlspecialchars($submission['id_proof']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>EPF Statements</th>
                        <td><a href="<?php echo htmlspecialchars($$submission['epf_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Bank Statements</th>
                        <td><a href="<?php echo htmlspecialchars($submission['bank_statements']); ?>" target="_blank">View Document</a></td>
                    </tr>
                    <tr>
                        <th>Payslips</th>
                        <td><a href="<?php echo htmlspecialchars($submission['payslips']); ?>" target="_blank">View Document</a></td>
                    </tr>
            </tbody>
        </table>
        <a href="banker_previous_loan_submission.php" class="btn btn-secondary">Back to Previous Submissions</a>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>

