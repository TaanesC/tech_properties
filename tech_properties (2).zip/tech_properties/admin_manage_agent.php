<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

$searchQuery = "";
if (isset($_POST['search'])) {
    $searchInput = $_POST['search_input'];
    $searchQuery = "WHERE agent_id LIKE '%$searchInput%' 
                    OR agent_email LIKE '%$searchInput%' 
                    OR agent_fullname LIKE '%$searchInput%' 
                    OR agent_phonenumber LIKE '%$searchInput%' 
                    OR ren_number LIKE '%$searchInput%'";
}

$query = "SELECT agent_id, agent_email, agent_fullname, agent_phonenumber, ren_number FROM agents $searchQuery";
$result = $conn->query($query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Agents | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            padding: 20px;
            width: 100%;
            position: fixed;
            top: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 80px;
            padding: 20px;
        }
        .search-bar {
            margin-bottom: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .btn-analytics {
            background-color: #17a2b8;
            color: white;
        }
        .btn-delete {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
        <div class="ms-auto">
            <a href="admin_logout.php" class="btn btn-danger">Logout</a>
        </div>
    </nav>

    <div class="content container">
        <h1 class="text-center mb-4">Manage Agents</h1>
        
        <form method="POST" class="search-bar d-flex">
            <input type="text" name="search_input" class="form-control me-2" placeholder="Search by ID, email, name, phone, or REN number" value="<?php echo isset($searchInput) ? $searchInput : ''; ?>">
            <button type="submit" name="search" class="btn btn-primary">Search</button>
        </form>
        
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Agent ID</th>
                    <th>Email</th>
                    <th>Full Name</th>
                    <th>Phone Number</th>
                    <th>REN Number</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($agent = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $agent['agent_id']; ?></td>
                            <td><?php echo $agent['agent_email']; ?></td>
                            <td><?php echo $agent['agent_fullname']; ?></td>
                            <td><?php echo $agent['agent_phonenumber']; ?></td>
                            <td><?php echo $agent['ren_number']; ?></td>
                            <td>
                                <a href="admin_specific_agent_analytics.php?agent_id=<?php echo $agent['agent_id']; ?>" class="btn btn-analytics me-2">Analytics</a>
                                <a href="admin_delete_agent.php?agent_id=<?php echo $agent['agent_id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this agent?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">No agents found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

