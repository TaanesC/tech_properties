<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['admin_id'])) {  
    header('Location: admin_login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .navbar-nav .nav-link {
            color: white;
            margin-left: 20px;
        }
        .navbar-nav .nav-link:hover {
            color: #ddd;
        }
        .content {
            margin-top: 80px;
        }
        .container {
            margin: auto;
            max-width: 1200px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
    <div class="navbar-nav ms-auto">
        <a class="nav-link" href="admin_logout.php">Logout</a>
    </div>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Admin Dashboard</h1>
        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Manage Users</h5>
                        <a href="admin_manage_users.php" class="btn btn-primary">Users</a>
                        <a href="admin_manage_lawyer.php" class="btn btn-primary">Lawyers</a>
                        <a href="admin_manage_banker.php" class="btn btn-primary">Bankers</a>
                        <a href="admin_manage_agent.php" class="btn btn-primary">Agents</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Register New</h5>
                        <a href="admin_register_lawyer.php" class="btn btn-success">Lawyer</a>
                        <a href="admin_register_banker.php" class="btn btn-success">Banker</a>
                        <a href="admin_register_agent.php" class="btn btn-success">Agent</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Analytics</h5>
                        <a href="admin_user_analytics.php" class="btn btn-info">User Analytics</a>
                        <a href="admin_rented_sold_analytics.php" class="btn btn-info">Rented/Sold Analytics</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ads Management</h5>
                        <a href="admin_ads_approval.php" class="btn btn-warning">Ads Approval</a>
                        <a href="admin_ads_deletion.php" class="btn btn-warning">Ads Deletion</a>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Tenancy Agreement Management</h5>
                        <a href="admin_tenancy_agreement_approval.php" class="btn btn-danger">Tenancy Agreement Approval</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
