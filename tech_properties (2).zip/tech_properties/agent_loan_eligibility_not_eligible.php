<?php
session_start();
include 'config.php';

$id = $_GET['eligibility_id'];

$query = "UPDATE loan_eligibility SET eligibility_status = 'rejected' WHERE eligibility_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    header("Location: agent_loan_eligibility.php");
    exit();
} else {
    echo "Failed to update status.";
}
?>


