<?php
session_start();
include 'config.php';

if (!isset($_GET['submission_id'])) {
    die("Submission ID not provided.");
}

$submission_id = $_GET['submission_id'];

$query = "SELECT * FROM loan_submissions WHERE submission_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $submission_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("No loan submission found.");
}

$submission = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Submission Details</title>
    
    <style>
    .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        
        </style>
</head>
<body>
    
    
    
<nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="user_dashboard.php">TECH PROPERTIES</a>
    </nav>
    
    <div>rrr</div>
    
    
<div class="container mt-5">
    <h2>Loan Submission Details</h2>
    <table class="table">
        <tr>
            <th>Loan Amount</th>
            <td><?php echo htmlspecialchars($submission['loan_amount']); ?></td>
        </tr>
        <tr>
            <th>ID Proof</th>
            <td><a href="<?php echo htmlspecialchars($submission['id_proof']); ?>" target="_blank">View Document</a></td>
        </tr>
        <tr>
            <th>EPF Statements</th>
            <td><a href="<?php echo htmlspecialchars($submission['epf_statements']); ?>" target="_blank">View Document</a></td>
        </tr>
        <tr>
            <th>Bank Statements</th>
            <td><a href="<?php echo htmlspecialchars($submission['bank_statements']); ?>" target="_blank">View Document</a></td>
        </tr>
        <tr>
            <th>Payslips</th>
            <td><a href="<?php echo htmlspecialchars($submission['payslips']); ?>" target="_blank">View Document</a></td>
        </tr>
        <tr>
            <th>Status</th>
            <td><?php echo htmlspecialchars($submission['status']); ?></td>
        </tr>
        <tr>
            <th>Created At</th>
            <td><?php echo htmlspecialchars($submission['created_at']); ?></td>
        </tr>
    </table>
    <a href="user_loan_submission_results.php" class="btn btn-primary">Back to Results</a>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


