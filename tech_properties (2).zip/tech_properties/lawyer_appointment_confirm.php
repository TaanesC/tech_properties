<?php
session_start();
require 'config.php';

if (!isset($_SESSION['lawyer_id'])) {
    header('Location: lawyer_login.php');
    exit();
}

$lawyer_id = $_SESSION['lawyer_id'];

if (!isset($_GET['appointment_id'])) {
    echo "Invalid appointment ID.";
    exit();
}

$appointment_id = $_GET['appointment_id'];

$query = "UPDATE appointments SET appointment_status = 'confirmed' WHERE appointment_id = ? AND lawyer_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ii', $appointment_id, $lawyer_id);

if ($stmt->execute()) {
    echo "<script>alert('Appointment confirmed successfully!'); window.location.href='lawyer_appointment_schedule_user.php';</script>";
} else {
    echo "Error confirming appointment: " . $conn->error;
}

$stmt->close();
$conn->close();
?>


