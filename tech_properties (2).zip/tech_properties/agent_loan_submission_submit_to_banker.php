<?php
session_start();
include 'config.php';

$submission_id = null;
$bankers = [];

if (isset($_GET['submission_id'])) {
    $submission_id = intval($_GET['submission_id']); 
} else {
    die("No submission ID provided.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (isset($_POST['submission_id']) && isset($_POST['banker_id'])) {
        $submission_id = $_POST['submission_id'];
        $banker_id = $_POST['banker_id'];

        echo "Submission ID: $submission_id <br>";
        echo "Banker ID: $banker_id <br>";
        
        $checkQuery = "SELECT * FROM loan_submissions WHERE submission_id = ?";
        $checkStmt = $conn->prepare($checkQuery);
        $checkStmt->bind_param("i", $submission_id);
        $checkStmt->execute();
        $checkResult = $checkStmt->get_result();

        if ($checkResult->num_rows === 0) {
            die("No submission found with ID: " . htmlspecialchars($submission_id));
        }

        $updateQuery = "UPDATE loan_submissions SET banker_id = ?, status = 'Submitted' WHERE submission_id = ?";
        $stmt = $conn->prepare($updateQuery);
        
        if ($stmt) {
            $stmt->bind_param("ii", $banker_id, $submission_id);
            if ($stmt->execute()) {
                // Check if any rows were affected
                if ($stmt->affected_rows > 0) {
                    header("Location: agent_loan_submission.php?status=submitted");
                    exit();
                } else {
                    die("No rows were updated. Check if the submission ID is valid.");
                }
            } else {
                die("Error executing update: " . $stmt->error);
            }
            $stmt->close();
        } else {
            die("Error preparing statement: " . $conn->error);
        }
    } else {
        die("Submission ID or Banker ID is missing.");
    }
}

$query = "SELECT banker_id, bank_name, banker_fullname FROM bankers";
$result = $conn->query($query);
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $bankers[] = $row;
    }
} else {
    die("Error fetching bankers: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Select Banker</title>
</head>
<body>
<div class="container mt-5">
    <h2>Select a Banker to Submit Loan Application</h2>
    <form action="" method="POST">
        <input type="hidden" name="submission_id" value="<?php echo htmlspecialchars($submission_id); ?>">
        <div class="form-group">
            <label for="banker_id">Select Banker:</label>
            <select name="banker_id" class="form-control" required>
                <option value="">Select a banker</option>
                <?php foreach ($bankers as $banker): ?>
                    <option value="<?php echo $banker['banker_id']; ?>">
                        <?php echo htmlspecialchars($banker['bank_name']) . " - " . htmlspecialchars($banker['banker_fullname']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
</div>
</body>
</html>

<?php
$conn->close();
?>




