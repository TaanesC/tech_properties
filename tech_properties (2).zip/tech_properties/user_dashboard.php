<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT user_email, user_phonenumber, user_fullname, created_at, profile_pic FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();
} else {
    echo "User not found.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f7f7f7;
        }
        .container {
            max-width: 800px;
            margin-top: 30px;
            background-color: white;
            padding: 90px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        
        }
        .logout-btn {
            margin-left: auto;
        }
    </style>
</head>
<body>

    <!-- Navbar/Header -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="property_listings.php">TECH PROPERTIES</a>
        <a href="user_logout.php" class="btn btn-danger logout-btn">Logout</a>
    </nav>

    <div class="container mt-5">
        <h2 class="text-center">User Dashboard</h2>

        <div class="text-center">
            <img src="<?php echo !empty($user['profile_pic']) ? $user['profile_pic'] : 'default_profile_pic.png'; ?>" alt="Profile Picture" class="rounded-circle" width="100" height="100">
        </div>
        
        <div class="mt-3">
            <h5><?php echo $user['user_fullname']; ?></h5>
            <p><strong>Email:</strong> <?php echo $user['user_email']; ?></p>
            <p><strong>Phone Number:</strong> <?php echo $user['user_phonenumber']; ?></p>
            <p><strong>Member Since:</strong> <?php echo date('F j, Y', strtotime($user['created_at'])); ?></p>
        </div>

        <div class="text-center mt-4">
            <a href="user_edit_profile.php" class="btn btn-primary">Edit Profile</a>
        </div>

        <div class="mt-4">
            <h5>Actions</h5>
            <div class="list-group">
                <a href="user_loan_submission_results.php" class="list-group-item list-group-item-action">Loan Submission Results</a>
                <a href="user_loan_eligibility_results.php" class="list-group-item list-group-item-action">Loan Eligibility Results</a>
                <a href="user_appointment_schedule.php" class="list-group-item list-group-item-action">Appointment Scheduling</a>
                <a href="user_tenancy_agreement.php" class="list-group-item list-group-item-action">Tenancy Agreement</a>
                <a href="user_messages.php" class="list-group-item list-group-item-action">Messages</a>
            </div>
        </div>
    </div>

</body>
</html>

