<?php
session_start();
require 'config.php'; 


if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit();
}

$user_id = $_SESSION['user_id'];


if (isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];

    
    $query = "UPDATE appointments SET appointment_status = 'confirmed' WHERE appointment_id = ? AND user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $appointment_id, $user_id);
    $stmt->execute();

    

    header('Location: user_appointment_schedule.php?status=confirmed');
} else {
    header('Location: user_appointment_schedule.php?error=invalid');
}
?>


