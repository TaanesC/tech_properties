-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 08, 2024 at 03:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tech_properties`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_email` varchar(255) NOT NULL,
  `admin_password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_email`, `admin_password`, `created_at`) VALUES
(3, 'admin@gmail.com', '$2y$10$kuRO6aZD2Bd9vQdqTfeDVe/n4gueSmzKEdGSIpf3/ioGeX4w1xL0q', '2024-11-02 21:26:30');

-- --------------------------------------------------------

--
-- Table structure for table `agents`
--

CREATE TABLE `agents` (
  `agent_id` int(11) NOT NULL,
  `ren_number` varchar(255) DEFAULT NULL,
  `agent_fullname` varchar(255) NOT NULL,
  `agent_email` varchar(255) NOT NULL,
  `agent_phonenumber` varchar(20) DEFAULT NULL,
  `agent_password` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `agents`
--

INSERT INTO `agents` (`agent_id`, `ren_number`, `agent_fullname`, `agent_email`, `agent_phonenumber`, `agent_password`, `profile_pic`, `created_at`) VALUES
(1, 'REN123456', 'agent', 'agent@gmail.com', '0187704305', '$2y$10$j.FCbjeOXIb0ZqH5XyEjFOW1dnAsw04IOgXfKAuJtA5DU7F4Ku9LG', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (2).jpg', '2024-11-02 21:29:03');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `lawyer_id` int(11) DEFAULT NULL,
  `banker_id` int(11) DEFAULT NULL,
  `appointment_date` datetime DEFAULT NULL,
  `appointment_status` enum('pending','confirmed','rescheduled','cancelled') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `property_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `user_id`, `agent_id`, `lawyer_id`, `banker_id`, `appointment_date`, `appointment_status`, `created_at`, `property_id`) VALUES
(2, 1, 1, NULL, NULL, '2024-11-20 03:59:00', 'confirmed', '2024-11-02 22:28:26', 2),
(3, 1, 1, NULL, NULL, '2024-11-23 11:55:00', 'pending', '2024-11-02 22:44:55', 2),
(35, 1, 1, 1, 1, '2024-11-20 00:00:00', 'rescheduled', '2024-11-05 18:28:20', 3),
(36, 1, 1, NULL, NULL, '2024-11-21 21:09:00', 'rescheduled', '2024-11-06 13:09:11', 3),
(37, 1, 1, 1, 1, '2024-11-21 00:00:00', 'confirmed', '2024-11-06 13:14:48', 3);

-- --------------------------------------------------------

--
-- Table structure for table `bankers`
--

CREATE TABLE `bankers` (
  `banker_id` int(11) NOT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_id` varchar(255) DEFAULT NULL,
  `banker_fullname` varchar(255) NOT NULL,
  `banker_email` varchar(255) NOT NULL,
  `banker_phonenumber` varchar(20) DEFAULT NULL,
  `banker_password` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bankers`
--

INSERT INTO `bankers` (`banker_id`, `bank_name`, `bank_id`, `banker_fullname`, `banker_email`, `banker_phonenumber`, `banker_password`, `profile_pic`, `created_at`) VALUES
(1, 'bank', '123456', 'banker', 'banker@gmail.com', '0187704305', '$2y$10$K2QvW6C0KZ/GxzZFvhoKb.gCYWIrUIcFB2fv88X.d28h7XMNROXtC', 'uploads/Screenshot 2024-06-04 010502.png', '2024-11-02 21:28:21');

-- --------------------------------------------------------

--
-- Table structure for table `lawyers`
--

CREATE TABLE `lawyers` (
  `lawyer_id` int(11) NOT NULL,
  `firm_number` varchar(255) DEFAULT NULL,
  `lawyer_fullname` varchar(255) NOT NULL,
  `lawyer_email` varchar(255) NOT NULL,
  `lawyer_phonenumber` varchar(20) DEFAULT NULL,
  `lawyer_password` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lawyers`
--

INSERT INTO `lawyers` (`lawyer_id`, `firm_number`, `lawyer_fullname`, `lawyer_email`, `lawyer_phonenumber`, `lawyer_password`, `profile_pic`, `created_at`) VALUES
(1, '123456', 'lawyer', 'lawyer@gmail.com', '0187704305', '$2y$10$Y4FufJqyWTol4Ld2W1gyf.Y6/x52oO4GFpNp2cJVruObg0Oz1K2b.', NULL, '2024-11-02 21:27:25');

-- --------------------------------------------------------

--
-- Table structure for table `loan_eligibility`
--

CREATE TABLE `loan_eligibility` (
  `eligibility_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `id_proof` varchar(255) DEFAULT NULL,
  `epf_statements` varchar(255) DEFAULT NULL,
  `bank_statements` varchar(255) DEFAULT NULL,
  `payslips` varchar(255) DEFAULT NULL,
  `eligibility_status` enum('pending','approved','rejected') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `property_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan_eligibility`
--

INSERT INTO `loan_eligibility` (`eligibility_id`, `user_id`, `agent_id`, `id_proof`, `epf_statements`, `bank_statements`, `payslips`, `eligibility_status`, `created_at`, `property_id`) VALUES
(2, 1, 1, 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (1).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (1).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (2).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia.jpg', 'approved', '2024-11-02 23:30:05', 3),
(3, 1, 1, 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'approved', '2024-11-06 13:11:18', 3);

-- --------------------------------------------------------

--
-- Table structure for table `loan_submissions`
--

CREATE TABLE `loan_submissions` (
  `submission_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `banker_id` int(11) DEFAULT NULL,
  `loan_amount` decimal(10,2) DEFAULT NULL,
  `id_proof` varchar(255) DEFAULT NULL,
  `epf_statements` varchar(255) DEFAULT NULL,
  `bank_statements` varchar(255) DEFAULT NULL,
  `payslips` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected','submitted') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `property_id` int(11) DEFAULT NULL,
  `lawyer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `loan_submissions`
--

INSERT INTO `loan_submissions` (`submission_id`, `user_id`, `agent_id`, `banker_id`, `loan_amount`, `id_proof`, `epf_statements`, `bank_statements`, `payslips`, `status`, `created_at`, `property_id`, `lawyer_id`) VALUES
(1, 1, 1, 1, 600000.00, 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia.jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (1).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (2).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia.jpg', 'rejected', '2024-11-03 00:07:18', 3, 1),
(12, 1, 1, 1, 400000.00, 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'rejected', '2024-11-05 17:23:24', 3, NULL),
(13, 1, 1, 1, 600000.00, 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'uploads/WEB API DEVLOPMENT.pdf', 'approved', '2024-11-06 13:13:01', 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `banker_id` int(11) DEFAULT NULL,
  `lawyer_id` int(11) DEFAULT NULL,
  `sender` enum('user','agent','banker','lawyer') NOT NULL,
  `receiver` enum('user','agent','banker','lawyer') NOT NULL,
  `message_text` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `property_id` int(11) DEFAULT NULL,
  `token` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `user_id`, `agent_id`, `banker_id`, `lawyer_id`, `sender`, `receiver`, `message_text`, `created_at`, `property_id`, `token`) VALUES
(39, 1, 1, NULL, NULL, 'user', 'agent', 'Hello, I would like to inquire about this property.', '2024-11-07 16:22:38', 3, '1f641be650ee35d624f23af3d4c948a2'),
(40, 1, 1, NULL, NULL, 'user', 'agent', 'hi', '2024-11-07 16:22:44', 3, '1f641be650ee35d624f23af3d4c948a2'),
(41, 1, 1, NULL, NULL, 'agent', 'user', 'hi', '2024-11-07 16:22:57', 3, '1f641be650ee35d624f23af3d4c948a2'),
(42, 1, 1, NULL, NULL, 'user', 'agent', 'Hello, I would like to inquire about this property.', '2024-11-08 02:48:59', 3, '5d5bd0aabd1220cb60e25e5feb17889b');

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `property_id` int(11) NOT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `type` enum('apartment','house','condominium','flat') DEFAULT NULL,
  `rent_or_sale` enum('for_rent','for_sale') DEFAULT 'for_rent',
  `sqft` int(11) DEFAULT NULL,
  `bedrooms` int(11) DEFAULT NULL,
  `bathrooms` int(11) DEFAULT NULL,
  `cover_pic` varchar(255) DEFAULT NULL,
  `additional_pic_1` varchar(255) DEFAULT NULL,
  `additional_pic_2` varchar(255) DEFAULT NULL,
  `additional_pic_3` varchar(255) DEFAULT NULL,
  `additional_pic_4` varchar(255) DEFAULT NULL,
  `additional_pic_5` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `rented_or_sold` enum('available','rented','sold') DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`property_id`, `agent_id`, `title`, `description`, `price`, `location`, `type`, `rent_or_sale`, `sqft`, `bedrooms`, `bathrooms`, `cover_pic`, `additional_pic_1`, `additional_pic_2`, `additional_pic_3`, `additional_pic_4`, `additional_pic_5`, `created_at`, `status`, `rented_or_sold`) VALUES
(1, 1, 'NUSA BASU DOUBLE STOREY HOUSE', 'Good condition 2-Storey Terrace House near Tuas Checkpoint\r\n(Gelang Patah Nusa Bayu-Double Storey)\r\nNear to Tuas Checkpoint\r\n\r\nNo x, Jalan nusa bayu 6/x,Taman Nusa bayu\r\n\r\nDouble Storey Terrace\r\n- Intermediate\r\n- Freehold\r\n- Bumi (Can do bumi released)\r\n- Land Area :1200sf (20x60 )\r\n- 4 Rooms\r\n- 3 Bathrooms\r\n- Facing Southwest\r\n- Unblocked view\r\n- Basic renovation\r\n- Grille\r\n- Kitchen Cabinet\r\n', 590000.00, 'Jalan Nusa Bayu 6, Nusa Bayu, Iskandar Puteri (Nusajaya), Johor', 'house', 'for_sale', 1200, 2, 3, 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia.jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (1).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (2).jpg', NULL, NULL, NULL, '2024-11-02 21:43:37', 'approved', ''),
(2, 1, 'Nusa Bayu Nusas Bayus', '(Gelang Patah Nusa Bayu-Double Storey)\r\nNear to Tuas Checkpoint\r\n\r\nNo x, Jalan nusa bayu 6/x,Taman Nusa bayu\r\n\r\nDouble Storey Terrace\r\n- Intermediate\r\n- Freehold\r\n- Bumi (Can do bumi released)\r\n- Land Area :1200sf (20x60 )\r\n- 4 Rooms\r\n- 3 Bathrooms\r\n- Facing Southwest\r\n- Unblocked view\r\n- Basic renovation\r\n- Grille\r\n- Kitchen Cabinet\r\n', 1200.00, 'Jalan Nusa Bayu 6, Nusa Bayu, Iskandar Puteri (Nusajaya), Johor', 'house', 'for_rent', 1199, 4, 1, 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia.jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (1).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (2).jpg', NULL, NULL, NULL, '2024-11-02 22:00:00', 'approved', 'available'),
(3, 1, 'Taman Nusa Bayu Taman Nusa Bayu .', 'Taman Nusa Bayu, Iskandar Puteri\r\nLand size 20x70 sqft\r\nFacing South\r\nDouble Storey\r\nNon Bumi Lot\r\n4Bedroom 3bathroom\r\n\r\nExtended with mbip drawing approved\r\n\r\nselling price Rm720k\r\n', 720000.00, 'Nusa Bayu, Iskandar Puteri (Nusajaya), Johor', 'house', 'for_sale', 1400, 4, 1, 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia.jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (1).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (2).jpg', NULL, NULL, NULL, '2024-11-02 23:07:45', 'approved', 'rented'),
(4, 1, 'nusa', 'nusas', 300000.00, 'Jalan Nusa Bayu 6, Nusa Bayu, Iskandar Puteri (Nusajaya), Johor', 'house', 'for_sale', 1199, 3, 0, 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (2).jpg', 'uploads/Nusa-Bayu-Nusas-Bayus-Iskandar-Puteri-Nusajaya-Malaysia (1).jpg', NULL, NULL, NULL, NULL, '2024-11-03 02:46:10', 'approved', '');

-- --------------------------------------------------------

--
-- Table structure for table `rented_sold_analytics`
--

CREATE TABLE `rented_sold_analytics` (
  `analytics_id` int(11) NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `status` enum('rented','sold') DEFAULT NULL,
  `property_type` enum('apartment','house','condominium','flat') DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rented_sold_analytics`
--

INSERT INTO `rented_sold_analytics` (`analytics_id`, `property_id`, `agent_id`, `status`, `property_type`, `location`, `created_at`) VALUES
(1, 1, 1, 'sold', 'house', 'Jalan Nusa Bayu 6, Nusa Bayu, Iskandar Puteri (Nusajaya), Johor', '2024-11-02 21:54:50'),
(2, 4, 1, 'sold', 'house', 'Jalan Nusa Bayu 6, Nusa Bayu, Iskandar Puteri (Nusajaya), Johor', '2024-11-03 02:50:20');

-- --------------------------------------------------------

--
-- Table structure for table `tenancy_agreements`
--

CREATE TABLE `tenancy_agreements` (
  `agreement_id` int(11) NOT NULL,
  `property_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `lawyer_id` int(11) DEFAULT NULL,
  `tenant_ic` varchar(255) DEFAULT NULL,
  `tenant_address` text DEFAULT NULL,
  `landlord_ic` varchar(255) DEFAULT NULL,
  `landlord_address` text DEFAULT NULL,
  `property_address` text DEFAULT NULL,
  `monthly_rental` decimal(10,2) DEFAULT NULL,
  `deposit` decimal(10,2) DEFAULT NULL,
  `rental_start_date` date DEFAULT NULL,
  `rental_end_date` date DEFAULT NULL,
  `contract_period` varchar(50) DEFAULT NULL,
  `status` enum('pending','submitted','stamped','rejected') DEFAULT 'pending',
  `agreement_pdf` varchar(255) DEFAULT NULL,
  `stamped_agreement_pdf` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `tenant_fullname` varchar(255) NOT NULL,
  `landlord_fullname` varchar(255) NOT NULL,
  `user_signed_agreement_pdf` varchar(255) DEFAULT NULL,
  `landlord_signed_agreement_pdf` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tenancy_agreements`
--

INSERT INTO `tenancy_agreements` (`agreement_id`, `property_id`, `user_id`, `agent_id`, `lawyer_id`, `tenant_ic`, `tenant_address`, `landlord_ic`, `landlord_address`, `property_address`, `monthly_rental`, `deposit`, `rental_start_date`, `rental_end_date`, `contract_period`, `status`, `agreement_pdf`, `stamped_agreement_pdf`, `created_at`, `tenant_fullname`, `landlord_fullname`, `user_signed_agreement_pdf`, `landlord_signed_agreement_pdf`) VALUES
(5, 3, 1, 1, 1, '02088445566', '2056, LORONG MAK YONG 4', '020819011559', '2057, LORONG MAK YONG 4', 'TAMAN RIA JAYA', 1400.00, 2400.00, '2024-11-14', '2025-11-14', '1', 'pending', 'agreement_pdf/agreement_0be1d1db56c4c9655eecbca9db347482.pdf', '', '2024-11-06 18:22:12', 'TAANES A/L SELVADURAI', 'SHAREN A/L SELVADURAI', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_fullname` varchar(255) NOT NULL,
  `user_phonenumber` varchar(20) DEFAULT NULL,
  `user_age` int(11) DEFAULT NULL,
  `user_occupation` varchar(100) DEFAULT NULL,
  `user_password` varchar(255) NOT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_email`, `user_fullname`, `user_phonenumber`, `user_age`, `user_occupation`, `user_password`, `profile_pic`, `created_at`) VALUES
(1, 'tmselvadurai@gmail.com', 'Taanes', '0187704305', 22, 'student', '$2y$10$AKtbCQ8oL3v1rJbwBHUBxePL/u9tpza6J7rgnO64lOndoYABFGIMu', 'uploads/WhatsApp Image 2023-09-30 at 23.03.29_c06bce7e.jpg', '2024-11-02 21:12:38');

-- --------------------------------------------------------

--
-- Table structure for table `user_analytics`
--

CREATE TABLE `user_analytics` (
  `analytics_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `property_searches` text DEFAULT NULL,
  `filter_location` varchar(255) DEFAULT NULL,
  `filter_price_range` varchar(100) DEFAULT NULL,
  `filter_property_type` enum('apartment','house','condominium','flat') DEFAULT NULL,
  `filter_bedrooms` int(11) DEFAULT NULL,
  `filter_bathrooms` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_email` (`admin_email`);

--
-- Indexes for table `agents`
--
ALTER TABLE `agents`
  ADD PRIMARY KEY (`agent_id`),
  ADD UNIQUE KEY `agent_email` (`agent_email`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `agent_id` (`agent_id`),
  ADD KEY `lawyer_id` (`lawyer_id`),
  ADD KEY `banker_id` (`banker_id`),
  ADD KEY `property_id` (`property_id`) USING BTREE;

--
-- Indexes for table `bankers`
--
ALTER TABLE `bankers`
  ADD PRIMARY KEY (`banker_id`),
  ADD UNIQUE KEY `banker_email` (`banker_email`);

--
-- Indexes for table `lawyers`
--
ALTER TABLE `lawyers`
  ADD PRIMARY KEY (`lawyer_id`),
  ADD UNIQUE KEY `lawyer_email` (`lawyer_email`);

--
-- Indexes for table `loan_eligibility`
--
ALTER TABLE `loan_eligibility`
  ADD PRIMARY KEY (`eligibility_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `agent_id` (`agent_id`),
  ADD KEY `fk_property` (`property_id`);

--
-- Indexes for table `loan_submissions`
--
ALTER TABLE `loan_submissions`
  ADD PRIMARY KEY (`submission_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `agent_id` (`agent_id`),
  ADD KEY `banker_id` (`banker_id`),
  ADD KEY `property_id` (`property_id`),
  ADD KEY `lawyer_id` (`lawyer_id`) USING BTREE;

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `agent_id` (`agent_id`),
  ADD KEY `banker_id` (`banker_id`),
  ADD KEY `lawyer_id` (`lawyer_id`),
  ADD KEY `property_id` (`property_id`);

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`property_id`),
  ADD KEY `agent_id` (`agent_id`);

--
-- Indexes for table `rented_sold_analytics`
--
ALTER TABLE `rented_sold_analytics`
  ADD PRIMARY KEY (`analytics_id`),
  ADD KEY `property_id` (`property_id`),
  ADD KEY `agent_id` (`agent_id`);

--
-- Indexes for table `tenancy_agreements`
--
ALTER TABLE `tenancy_agreements`
  ADD PRIMARY KEY (`agreement_id`),
  ADD KEY `property_id` (`property_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `agent_id` (`agent_id`),
  ADD KEY `lawyer_id` (`lawyer_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_email` (`user_email`);

--
-- Indexes for table `user_analytics`
--
ALTER TABLE `user_analytics`
  ADD PRIMARY KEY (`analytics_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `agents`
--
ALTER TABLE `agents`
  MODIFY `agent_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `bankers`
--
ALTER TABLE `bankers`
  MODIFY `banker_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lawyers`
--
ALTER TABLE `lawyers`
  MODIFY `lawyer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `loan_eligibility`
--
ALTER TABLE `loan_eligibility`
  MODIFY `eligibility_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `loan_submissions`
--
ALTER TABLE `loan_submissions`
  MODIFY `submission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `property_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `rented_sold_analytics`
--
ALTER TABLE `rented_sold_analytics`
  MODIFY `analytics_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tenancy_agreements`
--
ALTER TABLE `tenancy_agreements`
  MODIFY `agreement_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_analytics`
--
ALTER TABLE `user_analytics`
  MODIFY `analytics_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`),
  ADD CONSTRAINT `appointments_ibfk_3` FOREIGN KEY (`lawyer_id`) REFERENCES `lawyers` (`lawyer_id`),
  ADD CONSTRAINT `appointments_ibfk_4` FOREIGN KEY (`banker_id`) REFERENCES `bankers` (`banker_id`),
  ADD CONSTRAINT `fk_property_id` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `loan_eligibility`
--
ALTER TABLE `loan_eligibility`
  ADD CONSTRAINT `fk_property` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `loan_eligibility_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `loan_eligibility_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`);

--
-- Constraints for table `loan_submissions`
--
ALTER TABLE `loan_submissions`
  ADD CONSTRAINT `fk_lawyer_id` FOREIGN KEY (`lawyer_id`) REFERENCES `lawyers` (`lawyer_id`),
  ADD CONSTRAINT `loan_submissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `loan_submissions_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`),
  ADD CONSTRAINT `loan_submissions_ibfk_3` FOREIGN KEY (`banker_id`) REFERENCES `bankers` (`banker_id`),
  ADD CONSTRAINT `property_id` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_3` FOREIGN KEY (`banker_id`) REFERENCES `bankers` (`banker_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_4` FOREIGN KEY (`lawyer_id`) REFERENCES `lawyers` (`lawyer_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `messages_ibfk_5` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`) ON DELETE SET NULL;

--
-- Constraints for table `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `properties_ibfk_1` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`);

--
-- Constraints for table `rented_sold_analytics`
--
ALTER TABLE `rented_sold_analytics`
  ADD CONSTRAINT `rented_sold_analytics_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`),
  ADD CONSTRAINT `rented_sold_analytics_ibfk_2` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`);

--
-- Constraints for table `tenancy_agreements`
--
ALTER TABLE `tenancy_agreements`
  ADD CONSTRAINT `tenancy_agreements_ibfk_1` FOREIGN KEY (`property_id`) REFERENCES `properties` (`property_id`),
  ADD CONSTRAINT `tenancy_agreements_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `tenancy_agreements_ibfk_3` FOREIGN KEY (`agent_id`) REFERENCES `agents` (`agent_id`),
  ADD CONSTRAINT `tenancy_agreements_ibfk_4` FOREIGN KEY (`lawyer_id`) REFERENCES `lawyers` (`lawyer_id`);

--
-- Constraints for table `user_analytics`
--
ALTER TABLE `user_analytics`
  ADD CONSTRAINT `user_analytics_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
