<?php
session_start();
include 'config.php';

if (!isset($_SESSION['banker_id'])) {
    header("Location: banker_login.php");
    exit();
}

$banker_id = $_SESSION['banker_id'];

$query = "SELECT bank_name, bank_id, banker_fullname, banker_email, banker_phonenumber, banker_password, profile_pic FROM bankers WHERE banker_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $banker_id);
$stmt->execute();
$result = $stmt->get_result();
$banker = $result->fetch_assoc();

if (!$banker) {
    die("Banker not found.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_email = $_POST['banker_email'];
    $new_phone = $_POST['banker_phonenumber'];
    
    $new_profile_pic = $banker['profile_pic']; 

    if (isset($_FILES['profile_pic']) && $_FILES['profile_pic']['error'] == 0) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["profile_pic"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        $check = getimagesize($_FILES["profile_pic"]["tmp_name"]);

        if ($check !== false) {
            if (move_uploaded_file($_FILES["profile_pic"]["tmp_name"], $target_file)) {
                $new_profile_pic = $target_file; // Update profile pic path
            } else {
                echo "Sorry, there was an error uploading your file.";
            }
        } else {
            echo "File is not an image.";
        }
    }

    $update_query = "UPDATE bankers SET banker_email = ?, banker_phonenumber = ?, profile_pic = ? WHERE banker_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("sssi", $new_email, $new_phone, $new_profile_pic, $banker_id);
    
    if ($update_stmt->execute()) {
        echo "<script>alert('Profile updated successfully.');</script>";
        header("Refresh:0"); // Refresh the page to show updated data
    } else {
        echo "Error updating profile: " . $conn->error;
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Edit Profile</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Profile</h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="bank_name">Bank Name:</label>
                <input type="text" class="form-control" id="bank_name" value="<?php echo htmlspecialchars($banker['bank_name']); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="bank_id">Bank ID:</label>
                <input type="text" class="form-control" id="bank_id" value="<?php echo htmlspecialchars($banker['bank_id']); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="banker_fullname">Banker Full Name:</label>
                <input type="text" class="form-control" id="banker_fullname" value="<?php echo htmlspecialchars($banker['banker_fullname']); ?>" disabled>
            </div>
            <div class="form-group">
                <label for="banker_email">Banker Email:</label>
                <input type="email" class="form-control" id="banker_email" name="banker_email" value="<?php echo htmlspecialchars($banker['banker_email']); ?>" required>
            </div>
            <div class="form-group">
                <label for="banker_phonenumber">Banker Phone Number:</label>
                <input type="text" class="form-control" id="banker_phonenumber" name="banker_phonenumber" value="<?php echo htmlspecialchars($banker['banker_phonenumber']); ?>" required>
            </div>
            <div class="form-group">
                <label for="profile_pic">Profile Picture:</label>
                <input type="file" class="form-control" id="profile_pic" name="profile_pic" accept="image/*">
                <img src="<?php echo htmlspecialchars($banker['profile_pic']); ?>" alt="Profile Picture" class="img-thumbnail mt-2" width="150">
            </div>
            <button type="submit" class="btn btn-primary">Update Profile</button>
        </form>
        <a href="banker_dashboard.php" class="btn btn-secondary mt-3">Back to Dashboard</a>
    </div>
</body>
</html>

