<?php
session_start();
include 'config.php';

if (!isset($_SESSION['lawyer_id'])) {
    header("Location: lawyer_login.php");
    exit();
}

$lawyer_id = $_SESSION['lawyer_id'];

$query = "
    SELECT 
        ls.submission_id,
        a.ren_number,
        b.bank_id,
        b.bank_name,
        u.user_fullname,
        ls.id_proof,
        p.title,
        p.location,
        p.type,
        p.price,
        ls.created_at 
    FROM 
        loan_submissions ls 
    JOIN 
        users u ON ls.user_id = u.user_id
    JOIN 
        properties p ON ls.property_id = p.property_id
    JOIN 
        bankers b ON ls.banker_id = b.banker_id
    JOIN 
        agents a ON ls.agent_id = a.agent_id
    WHERE 
        ls.status = 'approved'
";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Approved Loan Submissions</title>
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="lawyer_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
        <div>rrr</div>


<div class="container mt-5">
    <h2>Approved Loan Submissions</h2>
    <table class="table">
        <thead>
            <tr>
                <th>REN Number</th>
                <th>Bank ID</th>
                <th>Bank Name</th>
                <th>User Full Name</th>
                <th>ID Proof</th>
                <th>Title</th>
                <th>Location</th>
                <th>Type</th>
                <th>Price</th>
                <th>Created At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['ren_number']); ?></td>
                    <td><?php echo htmlspecialchars($row['bank_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['bank_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['user_fullname']); ?></td>
                        <td><a href="<?php echo htmlspecialchars($details['id_proof']); ?>" target="_blank">View Document</a></td>
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['location']); ?></td>
                    <td><?php echo htmlspecialchars($row['type']); ?></td>
                    <td><?php echo htmlspecialchars($row['price']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                    <td>
                        <a href="lawyer_loan_submission_view_full_details.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-info">View Full Details</a>
                        <a href="lawyer_set_appointment_user.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-success">Set Appointment</a>
                        <a href="lawyer_message_user.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-warning">Contact Buyer</a>
                        <a href="lawyer_contact_agent.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-secondary">Contact Agent</a>
                        <a href="lawyer_contact_banker.php?submission_id=<?php echo $row['submission_id']; ?>" class="btn btn-dark">Contact Banker</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


