<?php
session_start();
include 'config.php';

if (!isset($_SESSION['agent_id'])) {
    header("Location: agent_login.php");
    exit();
}

$agent_id = $_SESSION['agent_id'];

$query = "
    SELECT 
     ls.*, 
        ls.submission_id, 
        u.user_fullname, 
        ls.id_proof, 
        p.title, 
        p.location, 
        p.type, 
        p.price, 
        ls.created_at, 
        ls.status 
    FROM 
        loan_submissions ls 
    JOIN 
        users u ON ls.user_id = u.user_id
    JOIN 
        properties p ON ls.property_id = p.property_id
    WHERE 
        ls.agent_id = ?
";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $agent_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <title>Loan Submission Status</title>
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="agent_dashboard.php">TECH PROPERTIES</a>
</nav>

<div class="container mt-5">
    <h2>Loan Submission Status</h2>
    <table class="table">
        <thead>
            <tr>
                <th>User Full Name</th>
                <th>ID Proof</th>
                <th>EPF statements</th>
                <th>Bank Statements</th>
                <th>Payslips</th>
                <th>Title</th>
                <th>Location</th>
                <th>Type</th>
                <th>Price</th>
                <th>Created Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['user_fullname']); ?></td>
                    
                        <td><a href="<?php echo htmlspecialchars($row['id_proof']); ?>" target="_blank">View Document</a></td>
                 
                        <td><a href="<?php echo htmlspecialchars($row['epf_statements']); ?>" target="_blank">View Document</a></td>
             
                   
                        <td><a href="<?php echo htmlspecialchars($row['bank_statements']); ?>" target="_blank">View Document</a></td>
          
                  
                        <td><a href="<?php echo htmlspecialchars($row['payslips']); ?>" target="_blank">View Document</a></td>
                    
                    <td><?php echo htmlspecialchars($row['title']); ?></td>
                    <td><?php echo htmlspecialchars($row['location']); ?></td>
                    <td><?php echo htmlspecialchars($row['type']); ?></td>
                    <td><?php echo htmlspecialchars($row['price']); ?></td>
                    <td><?php echo htmlspecialchars($row['created_at']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>


