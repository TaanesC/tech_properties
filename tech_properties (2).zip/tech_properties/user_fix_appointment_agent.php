<?php
session_start();
require 'config.php'; // Ensure the correct path to your config file

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php'); // Redirect to user login page
    exit();
}

// Get the property_id from the URL
if (!isset($_GET['property_id'])) {
    die("Property ID is required.");
}

$property_id = $_GET['property_id'];

// Fetch the agent_id based on the property_id
$query = "SELECT agent_id FROM properties WHERE property_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $property_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Property not found.");
}

$property = $result->fetch_assoc();
$agent_id = $property['agent_id'];

// Handle appointment submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $appointment_date = $_POST['appointment_date'];
    
    // Insert appointment into the database
    $insert_query = "INSERT INTO appointments (user_id, agent_id, appointment_date, appointment_status, created_at, property_id) 
                     VALUES (?, ?, ?, 'pending', NOW(), ?)";
    $insert_stmt = $conn->prepare($insert_query);
    $insert_stmt->bind_param('iisi', $user_id, $agent_id, $appointment_date, $property_id);
    
    if ($insert_stmt->execute()) {
        echo "<script>alert('Appointment fixed successfully!');</script>";
        // Optionally redirect to the user's dashboard or another page
        header('Location: user_dashboard.php');
        exit();
    } else {
        echo "<script>alert('Error fixing appointment. Please try again.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fix Appointment | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-datepicker/dist/css/bootstrap-datepicker.standalone.min.css">
    
     <style>
    .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        
        </style>

</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="user_dashboard.php">TECH PROPERTIES</a>
    </nav>
    
    <div>yy</div>
    
    <div>yy</div>

       <div class="container mt-4">
        <h2>Fix Appointment with Agent</h2>

        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="" method="POST">
            <div class="mb-3">
                <label for="appointment_date" class="form-label">Select Appointment Date and Time</label>
                <input type="datetime-local" name="appointment_date" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Fix Appointment</button>
        </form>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
</body>
</html>



