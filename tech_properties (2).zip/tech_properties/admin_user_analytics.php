<?php
require 'config.php';

$created_at_from = isset($_GET['created_at_from']) ? $_GET['created_at_from'] : '';
$created_at_to = isset($_GET['created_at_to']) ? $_GET['created_at_to'] : '';
$price_min = isset($_GET['price_min']) ? $_GET['price_min'] : '';
$price_max = isset($_GET['price_max']) ? $_GET['price_max'] : '';
$type = isset($_GET['type']) ? $_GET['type'] : '';
$rent_or_sale = isset($_GET['rent_or_sale']) ? $_GET['rent_or_sale'] : '';
$graph_type = isset($_GET['graph_type']) ? $_GET['graph_type'] : 'loan_submissions';

$query = "SELECT p.property_id, p.title, p.location, p.price, p.type, ls.created_at
          FROM loan_submissions ls
          JOIN properties p ON ls.property_id = p.property_id
          WHERE 1";

if ($created_at_from) {
    $query .= " AND ls.created_at >= ?";
}
if ($created_at_to) {
    $query .= " AND ls.created_at <= ?";
}

if ($price_min) {
    $query .= " AND p.price >= ?";
}
if ($price_max) {
    $query .= " AND p.price <= ?";
}

if ($type) {
    $query .= " AND p.type = ?";
}

if ($rent_or_sale) {
    $query .= " AND p.rent_or_sale = ?";
}

$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Query preparation failed: " . $conn->error);
}

$types = '';
$params = [];

if ($created_at_from) {
    $types .= 's';
    $params[] = $created_at_from;
}
if ($created_at_to) {
    $types .= 's';
    $params[] = $created_at_to;
}
if ($price_min) {
    $types .= 'i';
    $params[] = $price_min;
}
if ($price_max) {
    $types .= 'i';
    $params[] = $price_max;
}
if ($type) {
    $types .= 's';
    $params[] = $type;
}
if ($rent_or_sale) {
    $types .= 's';
    $params[] = $rent_or_sale;
}

if (!empty($types)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();

$data = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Analytics</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<style>
        .navbar {    
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;       
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
        <div>rrr</div>
         <div>rrr</div>
          

<div class="container mt-4">
    <h2>User Analytics</h2>

    <form method="GET" action="admin_user_analytics.php">
        <div class="row">
            <div class="col-md-3">
                <label for="created_at" class="form-label">Select Date Range</label>
                <input type="date" id="created_at_from" name="created_at_from" class="form-control" value="<?= isset($_GET['created_at_from']) ? $_GET['created_at_from'] : '' ?>">
                <input type="date" id="created_at_to" name="created_at_to" class="form-control mt-2" value="<?= isset($_GET['created_at_to']) ? $_GET['created_at_to'] : '' ?>">
            </div>

            <div class="col-md-3">
                <label for="price" class="form-label">Select Price Range</label>
                <input type="number" id="price_min" name="price_min" class="form-control" placeholder="Min Price" value="<?= isset($_GET['price_min']) ? $_GET['price_min'] : '' ?>">
                <input type="number" id="price_max" name="price_max" class="form-control mt-2" placeholder="Max Price" value="<?= isset($_GET['price_max']) ? $_GET['price_max'] : '' ?>">
            </div>

            <div class="col-md-3">
                <label for="type" class="form-label">Select Property Type</label>
                <select id="type" name="type" class="form-select">
                    <option value="">All</option>
                    <option value="apartment" <?= isset($_GET['type']) && $_GET['type'] == 'apartment' ? 'selected' : '' ?>>Apartment</option>
                    <option value="house" <?= isset($_GET['type']) && $_GET['type'] == 'house' ? 'selected' : '' ?>>House</option>
                </select>
            </div>

            <div class="col-md-3">
                <label for="rent_or_sale" class="form-label">Rent or Sale</label>
                <select id="rent_or_sale" name="rent_or_sale" class="form-select">
                    <option value="">All</option>
                    <option value="rent" <?= isset($_GET['rent_or_sale']) && $_GET['rent_or_sale'] == 'rent' ? 'selected' : '' ?>>Rent</option>
                    <option value="sale" <?= isset($_GET['rent_or_sale']) && $_GET['rent_or_sale'] == 'sale' ? 'selected' : '' ?>>Sale</option>
                </select>
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-md-3">
                <label for="graph_type" class="form-label">Select Graph</label>
                <select id="graph_type" name="graph_type" class="form-select">
                    <option value="loan_submissions" <?= isset($_GET['graph_type']) && $_GET['graph_type'] == 'loan_submissions' ? 'selected' : '' ?>>Loan Submissions</option>
                    <option value="check_eligibility" <?= isset($_GET['graph_type']) && $_GET['graph_type'] == 'check_eligibility' ? 'selected' : '' ?>>Check Eligibility</option>
                </select>
            </div>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Apply Filters</button>
    </form>

    <div id="graph-container" class="mt-4">
        <canvas id="analyticsGraph" width="400" height="200"></canvas>
    </div>
</div>

<script>
    const graphData = <?php echo json_encode($data); ?>;

    const labels = graphData.map(item => item.title); // Property titles as labels
    const values = graphData.map(item => item.price); // Property prices as values

    const ctx = document.getElementById('analyticsGraph').getContext('2d');
    const myChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Property Prices',
                data: values,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>

</body>
</html>





