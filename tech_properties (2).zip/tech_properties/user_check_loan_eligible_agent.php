<?php
session_start();
require 'config.php'; 
// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

// Retrieve property_id from the GET request
$property_id = isset($_GET['property_id']) ? $_GET['property_id'] : null;

// Fetch the agent_id using property_id
if ($property_id) {
    $query = "SELECT agent_id FROM properties WHERE property_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $property_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $property = $result->fetch_assoc();
        $agent_id = $property['agent_id'];
    } else {
        die("Invalid property ID.");
    }
} else {
    die("Property ID is required.");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Define allowed file types
    $allowed_types = ['application/pdf', 'image/jpeg', 'image/png'];
    
    // Handle file uploads
    $documents = [];
    $upload_errors = [];
    foreach (['id_proof', 'epf_statements', 'bank_statements', 'payslips'] as $doc) {
        if (isset($_FILES[$doc]) && $_FILES[$doc]['error'] == 0) {
            // Check file type
            if (in_array($_FILES[$doc]['type'], $allowed_types)) {
                // Define the upload path
                $upload_dir = 'uploads/'; // Ensure this directory exists and is writable
                $file_name = basename($_FILES[$doc]['name']);
                $upload_file = $upload_dir . $file_name;

                // Move the file to the upload directory
                if (move_uploaded_file($_FILES[$doc]['tmp_name'], $upload_file)) {
                    $documents[$doc] = $upload_file;
                } else {
                    $upload_errors[] = "Failed to upload $doc.";
                }
            } else {
                $upload_errors[] = "Invalid file type for $doc.";
            }
        }
    }

  if (empty($upload_errors)) {
    // Ensure to escape user input to prevent SQL injection
    $id_proof = $conn->real_escape_string($documents['id_proof']);
    $epf_statements = $conn->real_escape_string($documents['epf_statements']);
    $bank_statements = $conn->real_escape_string($documents['bank_statements']);
    $payslips = $conn->real_escape_string($documents['payslips']);
    
    // Prepare the query directly as a string
    $query = "INSERT INTO loan_eligibility 
              (user_id, agent_id, property_id, id_proof, epf_statements, bank_statements, payslips, eligibility_status, created_at) 
              VALUES 
              ($user_id, $agent_id, $property_id, '$id_proof', '$epf_statements', '$bank_statements', '$payslips', 'pending', NOW())";

    // Execute the query
    if ($conn->query($query) === TRUE) {
        echo "Loan eligibility documents submitted successfully.";
    } else {
        echo "Error submitting documents: " . $conn->error;
    }
}

else {
        foreach ($upload_errors as $error) {
            echo $error . "<br>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Loan Eligibility | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>   .navbar {
            background-color: #001f3f;
            padding: 15px 20px;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 24px;
        }</style>
</head>
<body>
   <nav class="navbar navbar-expand-lg">
        <a class="navbar-brand" href="property_listings.php">TECH PROPERTIES</a>
        <div class="ms-auto">
        <a href="user_dashboard.php" class="btn btn-outline-light">
            <i class="fas fa-user-circle"></i> Dashboard
        </a>
    </div>
    
</nav>

    <div class="container mt-4">
        <h2>Check Loan Eligibility</h2>
        <form action="" method="post" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="id_proof" class="form-label">ID Proof</label>
                <input type="file" class="form-control" name="id_proof" id="id_proof" required>
            </div>
            <div class="mb-3">
                <label for="epf_statements" class="form-label">EPF Statements</label>
                <input type="file" class="form-control" name="epf_statements" id="epf_statements" required>
            </div>
            <div class="mb-3">
                <label for="bank_statements" class="form-label">Bank Statements</label>
                <input type="file" class="form-control" name="bank_statements" id="bank_statements" required>
            </div>
            <div class="mb-3">
                <label for="payslips" class="form-label">Payslips</label>
                <input type="file" class="form-control" name="payslips" id="payslips" required>
            </div>
            <input type="hidden" name="property_id" value="<?= htmlspecialchars($property_id) ?>">
            <input type="hidden" name="agent_id" value="<?= htmlspecialchars($agent_id) ?>">
            <button type="submit" class="btn btn-primary">Submit Documents</button>
        </form>
    </div>
</body>
</html>





