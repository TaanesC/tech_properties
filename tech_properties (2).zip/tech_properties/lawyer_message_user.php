<?php
require 'config.php'; // Include your database connection
session_start();

$user_id = $_SESSION['lawyer_id'];
$token = isset($_GET['token']) ? $_GET['token'] : '';

// Fetch property_id using the token
$query = "SELECT property_id FROM messages WHERE token = ? LIMIT 1";
$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();
$message_data = $result->fetch_assoc();

if (!$message_data) {
    die("Message not found.");
}

$property_id = $message_data['property_id'];

// Get property and agent information
$query = "SELECT p.title, p.user_id, u.user_fullname 
          FROM properties p 
          JOIN users u ON p.user_id = a.user_id 
          WHERE p.property_id = ?";
$stmt = $conn->prepare($query);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}
$stmt->bind_param("i", $property_id);
$stmt->execute();
$result = $stmt->get_result();
$property = $result->fetch_assoc();

if (!$property) {
    die("Property not found.");
}

$agent_id = $property['agent_id'];
$property_title = $property['title'];

// Retrieve previous messages using the token
$query = "SELECT user_id, lawyer_id, sender, receiver, message_text, created_at 
          FROM messages 
          WHERE token = ? 
          ORDER BY created_at ASC";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $token);
$stmt->execute();
$messages = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle message submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message_text'])) {
    $message_text = trim($_POST['message_text']);
    
    if ($message_text !== "") {
        $sender_role = 'user';
        $receiver_role = 'agent';
        
        // Insert new message
        $insert_query = "INSERT INTO messages (message_id, user_id, agent_id, sender, receiver, message_text, created_at, property_id, token)
                         VALUES (NULL, ?, ?, ?, ?, ?, NOW(), ?, ?)";
        $stmt = $conn->prepare($insert_query);
        $stmt->bind_param("iisssis", $user_id, $agent_id, $sender_role, $receiver_role, $message_text, $property_id, $token);
        $stmt->execute();
        
        // Refresh to show the new message
        header("Location: user_message_agent.php?token=$token");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat with Agent</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>
    <!-- Navbar/Header -->
    <nav class="navbar navbar-expand-lg navbar-dark">
        <a class="navbar-brand" href="user_dashboard.php">TECH PROPERTIES</a>
    </nav>
    <div>rrr</div>
        <div>rrr</div>
            <div>rrr</div>



    <div class="container mt-4">
        <h3>Chat with Agent - <?= htmlspecialchars($property['agent_fullname']) ?></h3>
        <h5>Property: <?= htmlspecialchars($property_title) ?></h5>
        
        <div class="card mt-3">
            <div class="card-body" style="height: 400px; overflow-y: scroll;">
                <?php if ($messages): ?>
                    <?php foreach ($messages as $message): ?>
                        <?php if ($message['sender'] == 'agent'): ?>
                            <div class="d-flex justify-content-start mb-3">
                                <div class="bg-primary text-white p-2 rounded">
                                    <strong>Agent:</strong> <?= htmlspecialchars($message['message_text']) ?>
                                    <br><small><?= $message['created_at'] ?></small>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="d-flex justify-content-end mb-3">
                                <div class="bg-secondary text-white p-2 rounded">
                                    <strong>You:</strong> <?= htmlspecialchars($message['message_text']) ?>
                                    <br><small><?= $message['created_at'] ?></small>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No messages yet. Start the conversation!</p>
                <?php endif; ?>
            </div>
        </div>
        
        <form method="POST" action="" class="mt-3">
            <div class="input-group">
                <input type="text" name="message_text" class="form-control" placeholder="Type your message here..." required>
                <button type="submit" class="btn btn-primary">Send</button>
            </div>
        </form>
    </div>
</body>
</html>
