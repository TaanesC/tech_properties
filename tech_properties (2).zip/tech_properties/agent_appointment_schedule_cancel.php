<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];

if (isset($_GET['appointment_id'])) {
    $appointment_id = $_GET['appointment_id'];

    $query = "UPDATE appointments SET appointment_status = 'canceled' WHERE appointment_id = ? AND agent_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('ii', $appointment_id, $agent_id);
    $stmt->execute();

    header('Location: agent_appointment_schedule.php?status=canceled'); 
} else {
    header('Location: agent_appointment_schedule.php?error=invalid'); 
}
?>

