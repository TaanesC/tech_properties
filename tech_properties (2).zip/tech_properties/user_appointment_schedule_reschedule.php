<?php
session_start();
require 'config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: user_login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

if (!isset($_GET['appointment_id'])) {
    echo "Invalid appointment ID.";
    exit();
}

$appointment_id = $_GET['appointment_id'];

$query = "SELECT appointment_date, appointment_status FROM appointments WHERE appointment_id = ? AND user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ii', $appointment_id, $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo "Appointment not found.";
    exit();
}

$appointment = $result->fetch_assoc();

// Check if the appointment is eligible for rescheduling
if ($appointment['appointment_status'] !== 'pending') {
    echo "Only pending appointments can be rescheduled.";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_date = $_POST['new_date'];

    // Update the appointment date and status
    $update_query = "UPDATE appointments SET appointment_date = ?, appointment_status = 'rescheduled' WHERE appointment_id = ? AND user_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('sii', $new_date, $appointment_id, $user_id);

    if ($update_stmt->execute()) {
        echo "<script>alert('Appointment rescheduled successfully!'); window.location.href='user_appointments.php';</script>";
    } else {
        echo "Error updating appointment: " . $conn->error;
    }

    $update_stmt->close();
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reschedule Appointment | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h2>Reschedule Appointment</h2>
        <p>Current Appointment Date: <strong><?= htmlspecialchars($appointment['appointment_date']) ?></strong></p>
        
        <form method="POST">
            <div class="mb-3">
                <label for="new_date" class="form-label">New Appointment Date</label>
                <input type="date" class="form-control" id="new_date" name="new_date" required>
            </div>
            <button type="submit" class="btn btn-primary">Reschedule</button>
            <a href="user_appointment_schedule.php" class="btn btn-secondary">Cancel</a>
        </form>
    </div>
</body>
</html>
