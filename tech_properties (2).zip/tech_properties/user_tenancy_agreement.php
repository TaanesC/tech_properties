<?php
require_once 'config.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = $_SESSION['user_id'];

$query = "
    SELECT ta.*, p.title 
    FROM tenancy_agreements ta
    LEFT JOIN properties p ON ta.property_id = p.property_id
    WHERE ta.user_id = ?
";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Tenancy Agreements</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>My Tenancy Agreements</h1>
        
        <?php if ($result->num_rows > 0): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Property Title</th>
                        <th>Property Address</th>
                        <th>Monthly Rental</th>
                        <th>Deposit</th>
                        <th>Rental Start Date</th>
                        <th>Rental End Date</th>
                        <th>Contract Period</th>
                                                <th>Status</th>

                        <th>Agreement PDF</th>
                        <th>Upload Signed Document</th>
                                                <th>Stamped Agreement</th>

                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['title']); ?></td>
                            <td><?php echo htmlspecialchars($row['property_address']); ?></td>
                            <td><?php echo htmlspecialchars($row['monthly_rental']); ?></td>
                            <td><?php echo htmlspecialchars($row['deposit']); ?></td>
                            <td><?php echo htmlspecialchars($row['rental_start_date']); ?></td>
                            <td><?php echo htmlspecialchars($row['rental_end_date']); ?></td>
                            <td><?php echo htmlspecialchars($row['contract_period']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>


                            <td><a href="<?php echo htmlspecialchars($row['agreement_pdf']); ?>" target="_blank">View Agreement</a></td>
                            <td>
                                <?php if (empty($row['user_signed_agreement_pdf'])): ?>
                                    <form action="upload_signed_agreement.php" method="POST" enctype="multipart/form-data">
                                        <input type="hidden" name="agreement_id" value="<?php echo $row['agreement_id']; ?>">
                                        <input type="file" name="signed_agreement" class="form-control" required>
                                        <button type="submit" class="btn btn-primary mt-2">Submit</button>
                                    </form>
                                <?php else: ?>
                                    <a href="<?php echo htmlspecialchars($row['user_signed_agreement_pdf']); ?>" target="_blank">View Signed Agreement</a>
                                <?php endif; ?>
                            </td>
                                                        <td><a href="<?php echo htmlspecialchars($row['stamped_agreement_pdf']); ?>" target="_blank">View Agreement</a></td>

                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No tenancy agreements found.</p>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

