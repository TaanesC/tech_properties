<?php
session_start();
require 'config.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit();
}

if (!isset($_GET['user_id'])) {
    echo "User ID is missing.";
    exit();
}

$user_id = $_GET['user_id'];

$query = "SELECT user_id, user_email, user_fullname, user_phonenumber, user_age, user_occupation
          FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}

$query = "SELECT user_id, user_email, user_fullname, user_phonenumber, user_age, user_occupation
          FROM users WHERE user_id = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error in user query preparation: " . $conn->error);
}

$stmt->bind_param('i', $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "User not found.";
    exit();
}

$query = "SELECT p.property_id, p.title, p.location, p.price, p.type, ls.created_at
          FROM loan_submissions ls
          JOIN properties p ON ls.property_id = p.property_id
          WHERE ls.user_id = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error in loan submissions query preparation: " . $conn->error);
}

$stmt->bind_param('i', $user_id);
$stmt->execute();
$loan_submissions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Loan Eligibility Checks
$query = "SELECT p.property_id, p.title, p.location, p.price, p.type, le.created_at 
          FROM loan_eligibility le
          JOIN properties p ON le.property_id = p.property_id
          WHERE le.user_id = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error in loan eligibility checks query preparation: " . $conn->error);
}

$stmt->bind_param('i', $user_id);
$stmt->execute();
$loan_eligibility_checks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Properties for Sale or Rental
$query = "SELECT property_id, title, location, price, type, status 
          FROM properties 
          WHERE EXISTS (
              SELECT 1 FROM loan_submissions ls WHERE ls.property_id = properties.property_id AND ls.user_id = ?
          ) OR EXISTS (
              SELECT 1 FROM loan_eligibility le WHERE le.property_id = properties.property_id AND le.user_id = ?
          )";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Error in user properties query preparation: " . $conn->error);
}

$stmt->bind_param('ii', $user_id, $user_id);
$stmt->execute();
$user_properties = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Analytics | TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
 <style>
        .navbar {
            background-color: #001f3f;
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
    <a class="navbar-brand" href="admin_dashboard.php">TECH PROPERTIES</a>
</nav>
    
    <div>rrr</div>
        <div>rrr</div>
    <div class="container mt-5">
        <h2>User Analytics for <?= htmlspecialchars($user['user_fullname']) ?></h2>
        <table class="table table-bordered">
            <tr>
                <th>User ID</th>
                <td><?= htmlspecialchars($user['user_id']) ?></td>
            </tr>
            <tr>
                <th>Email</th>
                <td><?= htmlspecialchars($user['user_email']) ?></td>
            </tr>
            <tr>
                <th>Phone Number</th>
                <td><?= htmlspecialchars($user['user_phonenumber']) ?></td>
            </tr>
            <tr>
                <th>Age</th>
                <td><?= htmlspecialchars($user['user_age']) ?></td>
            </tr>
            <tr>
                <th>Occupation</th>
                <td><?= htmlspecialchars($user['user_occupation']) ?></td>
            </tr>
        </table>
        
        <!-- Loan Submissions -->
        <h3>Loan Submissions</h3>
        <?php if (count($loan_submissions) > 0): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Property ID</th>
                        <th>Title</th>
                        <th>Location</th>
                        <th>Price</th>
                        <th>Type</th>
                        <th>Submission Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($loan_submissions as $submission): ?>
                        <tr>
                            <td><?= htmlspecialchars($submission['property_id']) ?></td>
                            <td><?= htmlspecialchars($submission['title']) ?></td>
                            <td><?= htmlspecialchars($submission['location']) ?></td>
                            <td><?= htmlspecialchars($submission['price']) ?></td>
                            <td><?= htmlspecialchars($submission['type']) ?></td>
                            <td><?= htmlspecialchars($submission['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No loan submissions found for this user.</p>
        <?php endif; ?>

        <!-- Loan Eligibility Checks -->
        <h3>Loan Eligibility Checks</h3>
        <?php if (count($loan_eligibility_checks) > 0): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Property ID</th>
                        <th>Title</th>
                        <th>Location</th>
                        <th>Price</th>
                        <th>Type</th>
                        <th>Check Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($loan_eligibility_checks as $eligibility): ?>
                        <tr>
                            <td><?= htmlspecialchars($eligibility['property_id']) ?></td>
                            <td><?= htmlspecialchars($eligibility['title']) ?></td>
                            <td><?= htmlspecialchars($eligibility['location']) ?></td>
                            <td><?= htmlspecialchars($eligibility['price']) ?></td>
                            <td><?= htmlspecialchars($eligibility['type']) ?></td>
                            <td><?= htmlspecialchars($eligibility['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No loan eligibility checks found for this user.</p>
        <?php endif; ?>

        <!-- Properties for Sale or Rental -->
        <h3>Properties for Sale or Rental</h3>
        <?php if (count($user_properties) > 0): ?>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Property ID</th>
                        <th>Title</th>
                        <th>Location</th>
                        <th>Price</th>
                        <th>Type</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($user_properties as $property): ?>
                        <tr>
                            <td><?= htmlspecialchars($property['property_id']) ?></td>
                            <td><?= htmlspecialchars($property['title']) ?></td>
                            <td><?= htmlspecialchars($property['location']) ?></td>
                            <td><?= htmlspecialchars($property['price']) ?></td>
                            <td><?= htmlspecialchars($property['type']) ?></td>
                            <td><?= htmlspecialchars($property['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No properties found for this user.</p>
        <?php endif; ?>
        
        <a href="admin_manage_users.php" class="btn btn-secondary">Back to Users</a>
    </div>
</body>
</html>


