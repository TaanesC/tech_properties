<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];
$error = $success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price']; // Decimal with RM prefix
    $location = $_POST['location'];
    $type = $_POST['type'];
    $rent_or_sale = $_POST['rent_or_sale'];
    $sqft = $_POST['sqft'];
    $bedrooms = $_POST['bedrooms'];
    $bathrooms = $_POST['bathrooms'];

    $cover_pic = '';
    $additional_pic_1 = $additional_pic_2 = $additional_pic_3 = $additional_pic_4 = $additional_pic_5 = NULL;

    if (isset($_FILES['cover_pic']) && $_FILES['cover_pic']['error'] === UPLOAD_ERR_OK) {
        $cover_pic = 'uploads/' . basename($_FILES['cover_pic']['name']);
        move_uploaded_file($_FILES['cover_pic']['tmp_name'], $cover_pic);
    }

    $additional_pics = [
        'additional_pic_1' => 'uploads/' . basename($_FILES['additional_pic_1']['name']),
        'additional_pic_2' => 'uploads/' . basename($_FILES['additional_pic_2']['name']),
        'additional_pic_3' => 'uploads/' . basename($_FILES['additional_pic_3']['name']),
        'additional_pic_4' => 'uploads/' . basename($_FILES['additional_pic_4']['name']),
        'additional_pic_5' => 'uploads/' . basename($_FILES['additional_pic_5']['name']),
    ];

    foreach ($additional_pics as $key => $pic) {
        if (isset($_FILES[$key]) && $_FILES[$key]['error'] === UPLOAD_ERR_OK) {
            move_uploaded_file($_FILES[$key]['tmp_name'], $pic);
        } else {
            $additional_pics[$key] = NULL; 
        }
    }

    if ($title && $price && $location && $cover_pic) {
        $stmt = $conn->prepare("INSERT INTO properties (agent_id, title, description, price, location, type, rent_or_sale, sqft, bedrooms, bathrooms, cover_pic, additional_pic_1, additional_pic_2, additional_pic_3, additional_pic_4, additional_pic_5, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
        $stmt->bind_param("sssssssiisssssss", $agent_id, $title, $description, $price, $location, $type, $rent_or_sale, $sqft, $bedrooms, $bathrooms, $cover_pic, $additional_pics['additional_pic_1'], $additional_pics['additional_pic_2'], $additional_pics['additional_pic_3'], $additional_pics['additional_pic_4'], $additional_pics['additional_pic_5']);
        if ($stmt->execute()) {
            $success = "Property successfully added! It is pending admin approval.";
        } else {
            $error = "Error adding the property.";
        }
        $stmt->close();
    } else {
        $error = "Title, Price, Location, and Cover Picture are required!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Property - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%;
            padding: 20px;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 1000;
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 70px; 
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Add New Property</h1>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php elseif ($success): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="mb-3">
                <label for="title" class="form-label">Property Title</label>
                <input type="text" class="form-control" id="title" name="title" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description"></textarea>
            </div>

            <div class="mb-3">
                <label for="price" class="form-label">Price (RM)</label>
                <input type="number" class="form-control" id="price" name="price" step="0.01" required>
            </div>

            <div class="mb-3">
                <label for="location" class="form-label">Location</label>
                <input type="text" class="form-control" id="location" name="location" required>
            </div>

            <div class="mb-3">
                <label for="type" class="form-label">Type</label>
                <select class="form-select" id="type" name="type" required>
                    <option value="apartment">Apartment</option>
                    <option value="house">House</option>
                    <option value="condominium">Condominium</option>
                    <option value="flat">Flat</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="rent_or_sale" class="form-label">Rent or Sale</label>
                <select class="form-select" id="rent_or_sale" name="rent_or_sale" required>
                    <option value="for_rent">For Rent</option>
                    <option value="for_sale">For Sale</option>
                </select>
            </div>

            <div class="mb-3">
                <label for="sqft" class="form-label">Square Feet</label>
                <input type="number" class="form-control" id="sqft" name="sqft">
            </div>

            <div class="mb-3">
                <label for="bedrooms" class="form-label">Bedrooms</label>
                <input type="number" class="form-control" id="bedrooms" name="bedrooms">
            </div>

            <div class="mb-3">
                <label for="bathrooms" class="form-label">Bathrooms</label>
                <input type="number" class="form-control" id="bathrooms" name="bathrooms">
            </div>

            <div class="mb-3">
                <label for="cover_pic" class="form-label">Cover Picture</label>
                <input type="file" class="form-control" id="cover_pic" name="cover_pic" required>
            </div>

            <div class="mb-3">
                <label for="additional_pic_1" class="form-label">Additional Picture 1</label>
                <input type="file" class="form-control" id="additional_pic_1" name="additional_pic_1">
            </div>

            <div class="mb-3">
                <label for="additional_pic_2" class="form-label">Additional Picture 2</label>
                <input type="file" class="form-control" id="additional_pic_2" name="additional_pic_2">
            </div>

            <div class="mb-3">
                <label for="additional_pic_3" class="form-label">Additional Picture 3</label>
                <input type="file" class="form-control" id="additional_pic_3" name="additional_pic_3">
            </div>

            <div class="mb-3">
                <label for="additional_pic_4" class="form-label">Additional Picture 4</label>
                <input type="file" class="form-control" id="additional_pic_4" name="additional_pic_4">
            </div>

            <div class="mb-3">
                <label for="additional_pic_5" class="form-label">Additional Picture 5</label>
                <input type="file" class="form-control" id="additional_pic_5" name="additional_pic_5">
            </div>

            <button type="submit" class="btn btn-primary">Add Property</button>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>









