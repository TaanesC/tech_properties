<?php
require_once 'config.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['message_text'], $_POST['token'], $_POST['property_id'], $_POST['agent_id'])) {
    $message_text = $_POST['message_text'];
    $token = $_POST['token'];
    $property_id = $_POST['property_id'];
    $agent_id = $_POST['agent_id'];

    // Insert the new message
    $insert_query = "INSERT INTO messages (user_id, agent_id, sender, receiver, message_text, created_at, property_id, token) 
                     VALUES (?, ?, 'user', 'agent', ?, NOW(), ?, ?)";
    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param("iisss", $_SESSION['user_id'], $agent_id, $message_text, $property_id, $token);
    if ($stmt->execute()) {
        header("Location: user_message_agent.php?property_id=" . $property_id);
        exit();
    } else {
        echo "Error sending message.";
    }
}
?>


