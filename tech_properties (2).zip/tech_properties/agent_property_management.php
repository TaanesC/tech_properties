<?php
session_start();
require 'config.php'; 

if (!isset($_SESSION['agent_id'])) {
    header('Location: agent_login.php');
    exit();
}

$agent_id = $_SESSION['agent_id'];

$filter = isset($_GET['filter']) ? $_GET['filter'] : '';
$sort = isset($_GET['sort']) ? $_GET['sort'] : 'latest';

$sql = "SELECT * FROM properties WHERE agent_id = ? AND rented_or_sold = 'available'";

if ($filter) {
    $sql .= " AND rent_or_sale = ?";
}

switch ($sort) {
    case 'price_low_high':
        $sql .= " ORDER BY price ASC";
        break;
    case 'price_high_low':
        $sql .= " ORDER BY price DESC";
        break;
    case 'oldest':
        $sql .= " ORDER BY created_at ASC";
        break;
    case 'latest':
    default:
        $sql .= " ORDER BY created_at DESC";
        break;
}

$stmt = $conn->prepare($sql);
if ($filter) {
    $stmt->bind_param("ss", $agent_id, $filter);
} else {
    $stmt->bind_param("s", $agent_id);
}
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Property Management - TECH PROPERTIES</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar {
            background-color: #001f3f; 
            width: 100%; 
            padding: 20px;
            position: fixed; 
            top: 0;
            left: 0;
            z-index: 1000; 
        }
        .navbar-brand {
            color: white;
            font-weight: bold;
            font-size: 20px;
        }
        .content {
            margin-top: 70px;
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg">
    <a class="navbar-brand" href="#">TECH PROPERTIES</a>
</nav>

<div class="content">
    <div class="container">
        <h1 class="mt-4">Property Management</h1>

        <form method="GET" class="mb-3">
            <div class="row">
                <div class="col-md-4">
                    <select name="filter" class="form-select">
                        <option value="">All Properties</option>
                        <option value="for_rent" <?php echo ($filter == 'for_rent') ? 'selected' : ''; ?>>For Rent</option>
                        <option value="for_sale" <?php echo ($filter == 'for_sale') ? 'selected' : ''; ?>>For Sale</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <select name="sort" class="form-select">
                        <option value="latest" <?php echo ($sort == 'latest') ? 'selected' : ''; ?>>Latest to Oldest</option>
                        <option value="oldest" <?php echo ($sort == 'oldest') ? 'selected' : ''; ?>>Oldest to Latest</option>
                        <option value="price_low_high" <?php echo ($sort == 'price_low_high') ? 'selected' : ''; ?>>Price Low to High</option>
                        <option value="price_high_low" <?php echo ($sort == 'price_high_low') ? 'selected' : ''; ?>>Price High to Low</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>

        <a href="agent_property_management_add_new_property.php" class="btn btn-success mb-3">Add New Property</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Price</th>
                    <th>Location</th>
                    <th>Type</th>
                    <th>For Rent/Sale</th>
                    <th>Created Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['title']); ?></td>
                        <td><?php echo htmlspecialchars($row['price']); ?></td>
                        <td><?php echo htmlspecialchars($row['location']); ?></td>
                        <td><?php echo htmlspecialchars($row['type']); ?></td>
                        <td><?php echo htmlspecialchars($row['rent_or_sale']); ?></td>
                        <td><?php echo htmlspecialchars(date('Y-m-d', strtotime($row['created_at']))); ?></td>
                        <td>
                            <a href="agent_property_management_view_full.php?property_id=<?php echo $row['property_id']; ?>" class="btn btn-primary">View Full</a>
                            <a href="agent_property_management_edit.php?property_id=<?php echo $row['property_id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="agent_property_management_sold.php?id=<?php echo $row['property_id']; ?>" class="btn btn-danger btn-sm">Sold</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>






